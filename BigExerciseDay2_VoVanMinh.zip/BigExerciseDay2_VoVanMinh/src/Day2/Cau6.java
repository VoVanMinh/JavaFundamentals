package Day2;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Cau6 {

	public static void main(String[] args) {
		int chon = 10;
		String[][] maTran = null;
		do {
			@SuppressWarnings("resource")
			Scanner nhap = new Scanner(System.in);
			try {
				System.out.print("Nhan 0 de thoat! Nhap vao so tu 1 -> 7: ");
				chon = nhap.nextInt();
			} catch (InputMismatchException e) {
				System.out.println("Vui long nhap vao so.");
			}
			switch (chon) {
			case 1:
				maTran = maTranA();
				xuLyNull(maTran);
				xuatMaTran(maTran);
				break;

			case 2:
				maTran = maTranB();
				xuLyNull(maTran);
				xuatMaTran(maTran);
				break;
			case 3:
				maTran = maTranC();
				xuLyNull(maTran);
				xuatMaTran(maTran);
				break;
			case 4:
				maTran = maTranD();
				xuLyNull(maTran);
				xuatMaTran(maTran);
				break;
			case 5:
				maTran = maTranE();
				xuLyNull(maTran);
				xuatMaTran(maTran);
				break;
			case 6:
				maTran = maTranF();
				xuLyNull(maTran);
				xuatMaTran(maTran);
				break;
				
			case 7:
				maTran = maTranG();
				xuLyNull(maTran);
				xuatMaTran(maTran);
				break;
			default:
				break;
			}
		} while (chon != 0);
	}

	private static String[][] maTranG() {
		String[][] maTran = new String[8][8];
		int temp = 7;
		
		for (int i = 0; i < 8; i++) {
			int temp1 = 1;
			for (int j = temp; j >= 0; j--) {
				maTran[i][j] = String.valueOf(temp1);
				temp1++;
			}
			temp--;
		}
		return maTran;
	}

	private static String[][] maTranF() {
		String[][] maTran = new String[8][8];
		int temp = 0;
		
		for (int i = 7; i >=0; i--) {
			int temp1 = 1;
			for (int j = 7; j >= temp; j--) {
				maTran[i][j] = String.valueOf(temp1);
				temp1++;
			}
			temp++;
		}
		return maTran;
	}

	private static String[][] maTranE() {
		String[][] maTran = new String[8][8];
		
		for (int i = 0; i < 8; i ++) {
			int temp = 8;
			temp -= i;
			for (int j = 7; j >= i; j--) {
				maTran[i][j] = String.valueOf(temp);
				temp--;
			}
		}

		
		return maTran;
	}

	private static String[][] maTranD() {
		String[][] maTran = new String[8][8];
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j <= i; j++) {
				maTran[i][j] = String.valueOf(j+1);
			}
		}
		return maTran;
	}

	private static String[][] maTranC() {
		String[][] maTran = new String[11][11];
		int temp = 10;
		int temp1 = 0;
		for (int i = 5; i < maTran.length; i++) {
			for (int j = temp1; j <= temp; j++) {
				maTran[i][j] = "#";
			}
			temp--;
			temp1++;
		}
		
		temp = 9;
		temp1 = 1;
		for (int i = 4; i >= 0; i--) {
			for (int j = temp; j >= temp1; j--) {
				maTran[i][j] = "#";
			}
			temp--;
			temp1++;
		}
		
		
		return maTran;
		
		
	}

	private static String[][] maTranB() {
		String[][] maTran = new String[7][12];
		int temp = 0;
		int temp1 = 11;
		for (int i = 6; i >= 0; i--) {
			for (int j = temp1 - 1; j >= temp; j--) {
				maTran[i][j] = "#";
			}
			temp++;
			temp1--;
		}
		return maTran;
	}

	private static String[][] maTranA() {

		String[][] maTran = new String[7][12];
		int temp = 11;
		for (int i = 0; i < maTran.length; i++) {
			for (int j = i + 1; j <= temp; j++) {
				maTran[i][j] = "#";
			}
			temp--;
		}
		return maTran;

	}

	private static void xuLyNull(String[][] maTran) {
		for (int i = 0; i < maTran.length; i++) {
			for (int j = 0; j < maTran[0].length; j++) {
				if (maTran[i][j] == null)
					maTran[i][j] = " ";
			}
		}

	}

	private static void xuatMaTran(String[][] maTran) {
		for (int i = 0; i < maTran.length; i++) {
			for (int j = 0; j < maTran[0].length; j++) {
				if (maTran[i][j] != null)
					System.out.print(maTran[i][j]);
			}
			System.out.print("\n");
		}

	}

}
