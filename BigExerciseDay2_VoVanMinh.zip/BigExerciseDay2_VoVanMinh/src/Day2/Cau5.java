package Day2;

public class Cau5 {

	public static void main(String[] args) {

		for (int i = 0; i < 8; i++) {
			System.out.println("\n -----------------------------------------------");

			if (i % 2 == 0) {
				for (int j = 0; j < 4; j++) {
					System.out.print(" | W | | B |");
				}
			} else {
				for (int j = 0; j < 4; j++) {
					System.out.print(" | B | | W |");
				}
			}

		}
		System.out.println("\n -----------------------------------------------");

	}

}
