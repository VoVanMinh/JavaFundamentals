package Day2;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Cau2 {

	final static float SOKHOI[] = { 4, 6 };
	final static float GIANUOC[] = { 5300, 10200, 11400, 9600, 10300, 16900 };
	final static float THUE = 0.05f;
	final static float PHIMOITRUONG = 0.1f;

	public static void main(String[] args) {

		@SuppressWarnings("resource")
		Scanner nhap = new Scanner(System.in);

		try {
			float soKhoi = 0;
			while (soKhoi <= 0) {
				System.out.println("Nhap vao so m3 nuoc da dung >= 1: ");
				soKhoi = nhap.nextInt();
			}

			System.out.println("Chong doi tuong: 1. Sinh hoat/2. Khong Sinh hoat: ");
			int doiTuong = -1;
			while (doiTuong != 1 && doiTuong != 2) {
				System.out.println("Nhap so 1 hoac 2: ");
				doiTuong = nhap.nextInt();
			}

			if (doiTuong == 1) {
				int soNguoi = -1;
				while (soNguoi < 1) {
					System.out.println("Nhap vao so nguoi trong ho gia dinh cua ban >=1: ");
					soNguoi = nhap.nextInt();
				}
				tinhSinhHoat(soKhoi, soNguoi);

			} else {

				int loai = -1;
				while (loai != 1 && loai != 2 && loai != 3) {
					System.out.println(
							"Nhap vao loai: 1. Don vi san xuat /2. Co quan, Doan the,.../3. Don vi kinh doanh, dich vu: ");
					System.out.println("Nhap so  hoac 2 hoac 3: ");
					loai = nhap.nextInt();
				}
				tinhKhongSinhHoat(soKhoi, loai);

			}

		} catch (InputMismatchException e) {
			System.out.println("Ban da nhap sai!");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	private static void tinhKhongSinhHoat(float soKhoi, int loai) {

		float tongTien = 0;
		
		if(loai == 1){
			
			tongTien = GIANUOC[3]*soKhoi;
			
		}else if(loai == 2){
			
			tongTien = GIANUOC[4]*soKhoi;
			
		}else{
			
			tongTien = GIANUOC[5]*soKhoi;
			
		}
		
		float tienTHUE = tongTien*THUE;
		float tienMoiTruong = tongTien*PHIMOITRUONG;
		
		System.out.println("Tong so khoi la: " +soKhoi);
		System.out.println("Tien nuoc khong thue va phi la: " +tongTien);
		System.out.println("Tien thue la: " +tienTHUE);
		System.out.println("Tien Phi bao ve moi truong la: "+tienMoiTruong);
		System.out.println("Tong so tien phai tra la: " +(tongTien + tienTHUE + tienMoiTruong));
		
	}

	private static void tinhSinhHoat(float soKhoi, int soNguoi) {

		float trungBinh = (float) soKhoi / soNguoi;
		float tongTien = 0;

		if (trungBinh > SOKHOI[1]) {
			tongTien = (SOKHOI[0] * GIANUOC[0] + (SOKHOI[1] - SOKHOI[0]) * GIANUOC[1]
					+ (trungBinh - SOKHOI[1]) * GIANUOC[2]) * soNguoi;

		} else if (trungBinh > 4) {

			tongTien = (SOKHOI[0] * GIANUOC[0] + (trungBinh - SOKHOI[0]) * GIANUOC[1]) * soNguoi;

		} else {

			tongTien = (trungBinh * GIANUOC[0]) * soNguoi;
		}
		
		float tienTHUE = tongTien*THUE;
		float tienMoiTruong = tongTien*PHIMOITRUONG;
		
		System.out.println("Tong so khoi la: " +soKhoi);
		System.out.println("Tien nuoc khong thue va phi la: " +tongTien);
		System.out.println("Tien thue la: " +tienTHUE);
		System.out.println("Tien Phi bao ve moi truong la: "+tienMoiTruong);
		System.out.println("Tong so tien phai tra la: " +(tongTien + tienTHUE + tienMoiTruong));

	}

}
