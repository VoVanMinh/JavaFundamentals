package Day2;


import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class Cau3 {

	public static void main(String[] args) {

		@SuppressWarnings("resource")
		Scanner nhap = new Scanner(System.in);

		int[][] arr = new int[5][6];

		try {

			arr = mangNgauNhien(arr);

			int x = -1;
			while (x < 0 || x > 5) {
				System.out.println("Nhap vao mot so tu 0 den 5: ");
				x = nhap.nextInt();
			}
			arr = sapXepCot(arr, x);

			xuatMang(arr);

			System.out.println("Tong cac phan tu thuoc dong chan, cot le: " + tongDCCL(arr));

			thayGiaTriTru1(arr);

			xuatMang(arr);

			tongDCDC(arr);

			inSoChinhPhuong(arr);

		} catch (InputMismatchException e) {
			System.out.println("Vui long nhap vao so.");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	private static boolean laSoCP(int x) {
		if (x == 0)
			return false;
		int a = (int) Math.sqrt(x);
		if (a * a == x)
			return true;
		return false;

	}

	private static void inSoChinhPhuong(int[][] arr) {
		int temp = 0;
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[0].length; j++) {
				if (laSoCP(arr[i][j])) {
					System.out.println("So chinh phuong " + arr[i][j] + " o vi tri: [" + i + ":" + j + "]");
					temp = 1;
				}
			}
		}
		if (temp == 0)
			System.out.println("Ma tran khong co so chinh phuong!");

	}

	private static void tongDCDC(int[][] arr) {
		int tong1n = 0;
		int tongnn = 0;
		for (int i = 0; i < arr[0].length; i++) {
			tong1n += arr[0][i];
			tongnn += arr[arr.length - 1][i];
		}
		System.out.println("Tong cac phan tu dong dau tien: " + tong1n);
		System.out.println("Tong cac phan tu dong cuoi cung: " + tongnn);

		tong1n = 0;
		tongnn = 0;
		for (int i = 0; i < arr.length; i++) {
			tong1n += arr[i][0];
			tongnn += arr[i][arr[0].length - 1];
		}
		System.out.println("Tong cac phan tu cot dau tien: " + tong1n);
		System.out.println("Tong cac phan tu cot cuoi cung: " + tongnn);
	}

	private static boolean laNguyenTo(int x) {
		if (x < 2)
			return false;
		int c = (int) Math.sqrt(x);
		for (int i = 2; i <= c; i++) {
			if (x % i == 0) {
				return false;
			}
		}
		return true;
	}

	private static int[][] thayGiaTriTru1(int[][] arr) {

		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[0].length; j++) {
				if (laNguyenTo(arr[i][j]))
					arr[i][j] = -1;
			}
		}

		return arr;

	}

	private static int tongDCCL(int[][] arr) {
		int tong = 0;
		for (int i = 2; i < arr.length; i++) {
			if (i % 2 == 0) {
				for (int j = 1; j < arr[0].length; j++) {
					if (j % 2 == 1) {
						tong += arr[i][j];
					}
				}

			}

		}

		return tong;
	}

	private static int[][] sapXepCot(int[][] arr, int x) throws Exception {
		try{
		int temp = 0;
		for (int i = 0; i < arr.length - 1; i++) {
			for (int j = i + 1; j < arr[0].length; j++) {
				if (arr[i][x] > arr[j][x]) {
					temp = arr[i][x];
					arr[i][x] = arr[j][x];
					arr[j][x] = temp;
				}
			}
		}
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return arr;

	}

	private static int[][] mangNgauNhien(int[][] a) {
		Random random = new Random();
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[0].length; j++) {
				a[i][j] = random.nextInt(20);
			}
		}
		return a;
	}

	private static void xuatMang(int[][] arr) {

		System.out.println("\nMang hai chieu: ");
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[0].length; j++) {
				System.out.print(arr[i][j] + "\t");
			}
			System.out.print("\n");
		}

	}

}
