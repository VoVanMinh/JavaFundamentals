package Day2;

import java.util.Arrays;
import java.util.Scanner;

public class Cau7 {

	public static void main(String[] args) {

		try {
			@SuppressWarnings("resource")
			Scanner nhap = new Scanner(System.in);

			String[] mangTu = { "program", "developer", "testing", "coder", "algorithm", "bug", "console", "user",
					"system", "application" };

			int vitri = -1;

			System.out.println("Bo tu co 10 tu, ban muon doan tu o vi tri so may?");

			while (vitri < 1 || vitri > 10) {
				System.out.println("Nhap vao so tu 1 den 10: ");
				vitri = nhap.nextInt();
			}

			String[] arr = new String[mangTu[vitri - 1].length()];
			for (int i = 0; i < arr.length; i++) {
				arr[i] = String.valueOf(mangTu[vitri - 1].charAt(i));
			}

			String[] theHien = new String[arr.length];
			for (int i = 0; i < theHien.length; i++) {
				theHien[i] = "*";
			}

			System.out.println("Chieu dai cua tu ban muon doan la: " + arr.length);
			System.out.println(Arrays.toString(theHien));

			int soLanDoan = arr.length;
			while (soLanDoan > 0) {

				System.out.println("Nhap vao ki tu/ca tu muon doan: ");
				@SuppressWarnings("resource")
				Scanner nh = new Scanner(System.in);
				String kiTu = nh.nextLine();
				int temp = -1;
				if (kiTu.equals(mangTu[vitri - 1])) {
					System.out.println("Chuc mung ban da chien thang!");
					System.out.println(Arrays.toString(arr));
					temp = 2;
					soLanDoan = 0;
				} else {
					for (int i = 0; i < arr.length; i++) {
						if (arr[i].equalsIgnoreCase(kiTu)) {
							temp = 1;
							theHien[i] = arr[i];
						}
					}
				}
				if (temp == -1)
					System.out.println("Ban da chon sai!");
				else if (temp == 1) {
					System.out.println("Ban da doan dung");
					System.out.println(Arrays.toString(theHien));
				}
				soLanDoan--;
				if (soLanDoan == 0) {
					System.out.println("Ban da doan qua nhieu!");
				}
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

}
