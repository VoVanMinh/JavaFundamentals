package Day2;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Cau1 {

	final static int[] NKL = { 50, 100, 250, 500, 1000, 1500, 2000 };
	final static float[] NOITINH = { 8000, 8000, 10000, 12500, 15000, 18000, 21000, 1600, 50000, 5000, 50000, 5000 };
	final static float[] LTVUNG1 = { 8500, 12500, 16500, 23500, 33000, 40000, 48500, 3800, 70000, 7000, 70000, 7000 };
	final static float[] LTVUNG21 = { 9500, 13500, 20000, 26500, 38500, 49500, 59500, 8500, 110000, 12000, 85000,
			10000 };
	final static float[] LTVUNG22 = { 9500, 13500, 21500, 28000, 40500, 52500, 63500, 8500, 130000, 20000, 100000,
			12000 };
	final static float[] LTVUNG3 = { 10000, 14000, 22500, 29500, 43500, 55500, 67500, 9500, 110000, 15000 };

	public static void main(String[] args) {

		@SuppressWarnings("resource")
		Scanner nhap = new Scanner(System.in);

		try {
			int trongLuong = 0;
			while (trongLuong <= 0) {
				System.out.println("Nhap vao trong luong buu pham (gram): ");
				trongLuong = nhap.nextInt();
			}

			System.out.println("Nhap vao hinh thuc gui (Hinh thuc 1/Hinh thuc 2/Hinh thuc 3/: ");
			int hinhThuc = -1;
			while (hinhThuc != 1 && hinhThuc != 2 && hinhThuc != 3) {
				System.out.println("Nhap so 1 hoac 2 hoac 3: ");
				hinhThuc = nhap.nextInt();
			}

			System.out.println("Chon noi tinh(1) hoac lien tinh(2): ");
			int nlt = -1;
			while (nlt != 1 && nlt != 2) {
				System.out.println("Nhap so 1 hoac 2: ");
				nlt = nhap.nextInt();
			}
			int chonVung = -1;

			if (nlt == 2) {
				if (hinhThuc == 2) {
					System.out.println("Nhap vao vung: Vung 1/Vung 2 ");
					while (chonVung != 1 && chonVung != 2) {
						System.out.println("Nhap so 1 hoac 2: ");
						chonVung = nhap.nextInt();
					}
				} else {

					System.out.println("Nhap vao vung: Vung 1/Vung 2/Vung 3 ");
					while (chonVung != 1 && chonVung != 2 && chonVung != 3) {
						System.out.println("Nhap so 1 hoac 2 hoac 3: ");
						chonVung = nhap.nextInt();
					}
				}
				if (chonVung == 2) {
					chonVung = -1;
					System.out.println("Nhap vao dia diem co Da Nang hay khong? 1.Co  2. Khong ");
					while (chonVung != 1 && chonVung != 2) {
						System.out.println("Nhap so 1 hoac 2 ");
						chonVung = nhap.nextInt();
					}
					chonVung += 5;
				}

			}

			System.out.println("Tong cuoc phai tra la: " + tinhCuoc(trongLuong, hinhThuc, nlt, chonVung));

		} catch (InputMismatchException e) {
			System.out.println("Ban da nhap sai!");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public static double tinhCuoc(int trongLuong, int hinhThuc, int nlt, int chonVung) {
		double tongCuoc = 0;

		if (trongLuong > NKL[6]) {

			if (hinhThuc == 1) {
				if (nlt == 1) {
					tongCuoc = NOITINH[0] + NOITINH[1] + NOITINH[2] + NOITINH[3] + NOITINH[4] + NOITINH[5] + NOITINH[6]
							+ Math.round((float)((trongLuong - NKL[6]) / 500.0)) * NOITINH[7];
				} else {

					if (chonVung == 1) {
						tongCuoc = LTVUNG1[0] + LTVUNG1[1] + LTVUNG1[2] + LTVUNG1[3] + LTVUNG1[4] + LTVUNG1[5]
								+ LTVUNG1[6] + Math.round(((trongLuong - NKL[6]) / 500.0)) * LTVUNG1[7];
					} else if (chonVung == 3) {
						tongCuoc = LTVUNG3[0] + LTVUNG3[1] + LTVUNG3[2] + LTVUNG3[3] + LTVUNG3[4] + LTVUNG3[5]
								+ LTVUNG3[6] + Math.round(((trongLuong - NKL[6]) / 500.0)) * LTVUNG3[7];
					} else if (chonVung == 6) {
						tongCuoc = LTVUNG21[0] + LTVUNG21[1] + LTVUNG21[2] + LTVUNG21[3] + LTVUNG21[4] + LTVUNG21[5]
								+ LTVUNG21[6] + Math.round(((trongLuong - NKL[6]) / 500.0)) * LTVUNG21[7];
					} else {
						tongCuoc = LTVUNG22[0] + LTVUNG22[1] + LTVUNG22[2] + LTVUNG22[3] + LTVUNG22[4] + LTVUNG22[5]
								+ LTVUNG22[6] + Math.round(((trongLuong - NKL[6]) / 500.0)) * LTVUNG22[7];
					}
				}

			} else if (hinhThuc == 2) {

				if (nlt == 1) {
					tongCuoc = NOITINH[8] + Math.round(((trongLuong - NKL[6]) / 500.0)) * NOITINH[9];
				} else {

					if (chonVung == 1) {
						tongCuoc = LTVUNG1[8] + Math.round(((trongLuong - NKL[6])  / 500.0))* LTVUNG1[9];

					} else if (chonVung == 6) {
						tongCuoc = LTVUNG21[8] + Math.round(((trongLuong - NKL[6])  / 500.0))* LTVUNG21[9];
					} else {
						tongCuoc = LTVUNG22[8] + Math.round(((trongLuong - NKL[6])  / 500.0))* LTVUNG22[9];
					}
				}

			} else {

				if (nlt == 1) {
					tongCuoc = NOITINH[10] + (trongLuong - NKL[6]) * NOITINH[11] / 500.0;
				} else {

					if (chonVung == 1) {
						tongCuoc = LTVUNG1[10] + Math.round(((trongLuong - NKL[6])  / 500.0))* LTVUNG1[11];
					} else if (chonVung == 3) {
						tongCuoc = LTVUNG3[8] + Math.round(((trongLuong - NKL[6])  / 500.0))* LTVUNG3[9];
					} else if (chonVung == 6) {
						tongCuoc = LTVUNG21[10] + Math.round(((trongLuong - NKL[6])  / 500.0))* LTVUNG21[11];
					} else {
						tongCuoc = LTVUNG22[10] + Math.round(((trongLuong - NKL[6])  / 500.0))* LTVUNG22[11];
					}
				}

			}

		} else if (trongLuong > NKL[5]) {
			if (hinhThuc == 1) {
				if (nlt == 1) {
					tongCuoc = NOITINH[0] + NOITINH[1] + NOITINH[2] + NOITINH[3] + NOITINH[4] + NOITINH[5] + NOITINH[6];
				} else {

					if (chonVung == 1) {
						tongCuoc = LTVUNG1[0] + LTVUNG1[1] + LTVUNG1[2] + LTVUNG1[3] + LTVUNG1[4] + LTVUNG1[5]
								+ LTVUNG1[6];
					} else if (chonVung == 3) {
						tongCuoc = LTVUNG3[0] + LTVUNG3[1] + LTVUNG3[2] + LTVUNG3[3] + LTVUNG3[4] + LTVUNG3[5]
								+ LTVUNG3[6];
					} else if (chonVung == 6) {
						tongCuoc = LTVUNG21[0] + LTVUNG21[1] + LTVUNG21[2] + LTVUNG21[3] + LTVUNG21[4] + LTVUNG21[5]
								+ LTVUNG21[6];
					} else {
						tongCuoc = LTVUNG22[0] + LTVUNG22[1] + LTVUNG22[2] + LTVUNG22[3] + LTVUNG22[4] + LTVUNG22[5]
								+ LTVUNG22[6];
					}
				}

			} else if (hinhThuc == 2) {

				if (nlt == 1) {
					tongCuoc = NOITINH[8];
				} else {

					if (chonVung == 1) {
						tongCuoc = LTVUNG1[8];

					} else if (chonVung == 6) {
						tongCuoc = LTVUNG21[8];
					} else {
						tongCuoc = LTVUNG22[8];
					}
				}

			} else {

				if (nlt == 1) {
					tongCuoc = NOITINH[10];
				} else {

					if (chonVung == 1) {
						tongCuoc = LTVUNG1[10];
					} else if (chonVung == 3) {
						tongCuoc = LTVUNG3[8];
					} else if (chonVung == 6) {
						tongCuoc = LTVUNG21[10];
					} else {
						tongCuoc = LTVUNG22[10];
					}
				}

			}

		} else if (trongLuong > NKL[4]) {
			if (hinhThuc == 1) {
				if (nlt == 1) {
					tongCuoc = NOITINH[0] + NOITINH[1] + NOITINH[2] + NOITINH[3] + NOITINH[4] + NOITINH[5] + NOITINH[6];
				} else {

					if (chonVung == 1) {
						tongCuoc = LTVUNG1[0] + LTVUNG1[1] + LTVUNG1[2] + LTVUNG1[3] + LTVUNG1[4] + LTVUNG1[5];
					} else if (chonVung == 3) {
						tongCuoc = LTVUNG3[0] + LTVUNG3[1] + LTVUNG3[2] + LTVUNG3[3] + LTVUNG3[4] + LTVUNG3[5];
					} else if (chonVung == 6) {
						tongCuoc = LTVUNG21[0] + LTVUNG21[1] + LTVUNG21[2] + LTVUNG21[3] + LTVUNG21[4] + LTVUNG21[5];
					} else {
						tongCuoc = LTVUNG22[0] + LTVUNG22[1] + LTVUNG22[2] + LTVUNG22[3] + LTVUNG22[4] + LTVUNG22[5];
					}
				}

			} else if (hinhThuc == 2) {

				if (nlt == 1) {
					tongCuoc = NOITINH[8];
				} else {

					if (chonVung == 1) {
						tongCuoc = LTVUNG1[8];

					} else if (chonVung == 6) {
						tongCuoc = LTVUNG21[8];
					} else {
						tongCuoc = LTVUNG22[8];
					}
				}

			} else {

				if (nlt == 1) {
					tongCuoc = NOITINH[10];
				} else {

					if (chonVung == 1) {
						tongCuoc = LTVUNG1[10];
					} else if (chonVung == 3) {
						tongCuoc = LTVUNG3[8];
					} else if (chonVung == 6) {
						tongCuoc = LTVUNG21[10];
					} else {
						tongCuoc = LTVUNG22[10];
					}
				}

			}

		} else if (trongLuong > NKL[3]) {
			if (hinhThuc == 1) {
				if (nlt == 1) {
					tongCuoc = NOITINH[0] + NOITINH[1] + NOITINH[2] + NOITINH[3] + NOITINH[4] + NOITINH[5] + NOITINH[6];
				} else {

					if (chonVung == 1) {
						tongCuoc = LTVUNG1[0] + LTVUNG1[1] + LTVUNG1[2] + LTVUNG1[3] + LTVUNG1[4];
					} else if (chonVung == 3) {
						tongCuoc = LTVUNG3[0] + LTVUNG3[1] + LTVUNG3[2] + LTVUNG3[3] + LTVUNG3[4];
					} else if (chonVung == 6) {
						tongCuoc = LTVUNG21[0] + LTVUNG21[1] + LTVUNG21[2] + LTVUNG21[3] + LTVUNG21[4];
					} else {
						tongCuoc = LTVUNG22[0] + LTVUNG22[1] + LTVUNG22[2] + LTVUNG22[3] + LTVUNG22[4];
					}
				}

			} else if (hinhThuc == 2) {

				if (nlt == 1) {
					tongCuoc = NOITINH[8];
				} else {

					if (chonVung == 1) {
						tongCuoc = LTVUNG1[8];

					} else if (chonVung == 6) {
						tongCuoc = LTVUNG21[8];
					} else {
						tongCuoc = LTVUNG22[8];
					}
				}

			} else {

				if (nlt == 1) {
					tongCuoc = NOITINH[10];
				} else {

					if (chonVung == 1) {
						tongCuoc = LTVUNG1[10];
					} else if (chonVung == 3) {
						tongCuoc = LTVUNG3[8];
					} else if (chonVung == 6) {
						tongCuoc = LTVUNG21[10];
					} else {
						tongCuoc = LTVUNG22[10];
					}
				}

			}

		} else if (trongLuong > NKL[2]) {
			if (hinhThuc == 1) {
				if (nlt == 1) {
					tongCuoc = NOITINH[0] + NOITINH[1] + NOITINH[2] + NOITINH[3];
				} else {

					if (chonVung == 1) {
						tongCuoc = LTVUNG1[0] + LTVUNG1[1] + LTVUNG1[2] + LTVUNG1[3];
					} else if (chonVung == 3) {
						tongCuoc = LTVUNG3[0] + LTVUNG3[1] + LTVUNG3[2] + LTVUNG3[3];
					} else if (chonVung == 6) {
						tongCuoc = LTVUNG21[0] + LTVUNG21[1] + LTVUNG21[2] + LTVUNG21[3];
					} else {
						tongCuoc = LTVUNG22[0] + LTVUNG22[1] + LTVUNG22[2] + LTVUNG22[3];
					}
				}

			} else if (hinhThuc == 2) {

				if (nlt == 1) {
					tongCuoc = NOITINH[8];
				} else {

					if (chonVung == 1) {
						tongCuoc = LTVUNG1[8];

					} else if (chonVung == 6) {
						tongCuoc = LTVUNG21[8];
					} else {
						tongCuoc = LTVUNG22[8];
					}
				}

			} else {

				if (nlt == 1) {
					tongCuoc = NOITINH[10];
				} else {

					if (chonVung == 1) {
						tongCuoc = LTVUNG1[10];
					} else if (chonVung == 3) {
						tongCuoc = LTVUNG3[8];
					} else if (chonVung == 6) {
						tongCuoc = LTVUNG21[10];
					} else {
						tongCuoc = LTVUNG22[10];
					}
				}

			}

		} else if (trongLuong > NKL[1]) {
			if (hinhThuc == 1) {
				if (nlt == 1) {
					tongCuoc = NOITINH[0] + NOITINH[1] + NOITINH[2] + NOITINH[3];
				} else {

					if (chonVung == 1) {
						tongCuoc = LTVUNG1[0] + LTVUNG1[1] + LTVUNG1[2];
					} else if (chonVung == 3) {
						tongCuoc = LTVUNG3[0] + LTVUNG3[1] + LTVUNG3[2];
					} else if (chonVung == 6) {
						tongCuoc = LTVUNG21[0] + LTVUNG21[1] + LTVUNG21[2];
					} else {
						tongCuoc = LTVUNG22[0] + LTVUNG22[1] + LTVUNG22[2];
					}
				}

			} else if (hinhThuc == 2) {

				if (nlt == 1) {
					tongCuoc = NOITINH[8];
				} else {

					if (chonVung == 1) {
						tongCuoc = LTVUNG1[8];

					} else if (chonVung == 6) {
						tongCuoc = LTVUNG21[8];
					} else {
						tongCuoc = LTVUNG22[8];
					}
				}

			} else {

				if (nlt == 1) {
					tongCuoc = NOITINH[10];
				} else {

					if (chonVung == 1) {
						tongCuoc = LTVUNG1[10];
					} else if (chonVung == 3) {
						tongCuoc = LTVUNG3[8];
					} else if (chonVung == 6) {
						tongCuoc = LTVUNG21[10];
					} else {
						tongCuoc = LTVUNG22[10];
					}
				}

			}

		} else if (trongLuong > NKL[0]) {

			if (hinhThuc == 1) {
				if (nlt == 1) {
					tongCuoc = NOITINH[0] + NOITINH[1] + NOITINH[2] + NOITINH[3];
				} else {

					if (chonVung == 1) {
						tongCuoc = LTVUNG1[0] + LTVUNG1[1];
					} else if (chonVung == 3) {
						tongCuoc = LTVUNG3[0] + LTVUNG3[1];
					} else if (chonVung == 6) {
						tongCuoc = LTVUNG21[0] + LTVUNG21[1];
					} else {
						tongCuoc = LTVUNG22[0] + LTVUNG22[1];
					}
				}

			} else if (hinhThuc == 2) {

				if (nlt == 1) {
					tongCuoc = NOITINH[8];
				} else {

					if (chonVung == 1) {
						tongCuoc = LTVUNG1[8];

					} else if (chonVung == 6) {
						tongCuoc = LTVUNG21[8];
					} else {
						tongCuoc = LTVUNG22[8];
					}
				}

			} else {

				if (nlt == 1) {
					tongCuoc = NOITINH[10];
				} else {

					if (chonVung == 1) {
						tongCuoc = LTVUNG1[10];
					} else if (chonVung == 3) {
						tongCuoc = LTVUNG3[8];
					} else if (chonVung == 6) {
						tongCuoc = LTVUNG21[10];
					} else {
						tongCuoc = LTVUNG22[10];
					}
				}

			}

		} else // trongLuong < 50
		{
			if (hinhThuc == 1) {
				if (nlt == 1) {
					tongCuoc = NOITINH[0] + NOITINH[1] + NOITINH[2] + NOITINH[3];
				} else {

					if (chonVung == 1) {
						tongCuoc = LTVUNG1[0];
					} else if (chonVung == 3) {
						tongCuoc = LTVUNG3[0];
					} else if (chonVung == 6) {
						tongCuoc = LTVUNG21[0];
					} else {
						tongCuoc = LTVUNG22[0];
					}
				}

			} else if (hinhThuc == 2) {

				if (nlt == 1) {
					tongCuoc = NOITINH[8];
				} else {

					if (chonVung == 1) {
						tongCuoc = LTVUNG1[8];

					} else if (chonVung == 6) {
						tongCuoc = LTVUNG21[8];
					} else {
						tongCuoc = LTVUNG22[8];
					}
				}

			} else {

				if (nlt == 1) {
					tongCuoc = NOITINH[10];
				} else {

					if (chonVung == 1) {
						tongCuoc = LTVUNG1[10];
					} else if (chonVung == 3) {
						tongCuoc = LTVUNG3[8];
					} else if (chonVung == 6) {
						tongCuoc = LTVUNG21[10];
					} else {
						tongCuoc = LTVUNG22[10];
					}
				}

			}

		}

		return tongCuoc;
	}

}
