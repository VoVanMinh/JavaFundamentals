package Day2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;


public class Cau4 {

	public static void main(String[] args) {
		BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
		
		int n = -1;;
		try {
			while(n < 1){
				System.out.println("Nhap vao so nguyen duong n >=1: ");
				n = Integer.parseInt(nhap.readLine());				
			}
			
			float[] arr = new float[n];
			nhapMang(arr);
		
			System.out.println(Arrays.toString(arr));
			
			System.out.println("Diem trung binh: " +tinhDTB(arr));
			System.out.println("Diem lon nhat: " +diemLonNhat(arr));
			System.out.println("Diem nho nhat: " +diemNhoNhat(arr));

		} catch (NumberFormatException e) {
			System.out.println("Ban da nhap sai!");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	
	
	
	private static float diemLonNhat(float[] arr) {
		float lonNhat = arr[0];
		for (int i = 0; i < arr.length; i++) {
			if(arr[i] > lonNhat)
				lonNhat = arr[i];
		}
		
		return lonNhat;
		
		
	}

	private static float diemNhoNhat(float[] arr) {
		float nhoNhat = arr[0];
		for (int i = 0; i < arr.length; i++) {
			if(arr[i] < nhoNhat)
				nhoNhat = arr[i];
		}
		
		return nhoNhat;
	}




	public static float tinhDTB(float[] arr) {
		if(arr.length < 1)
			return 0;
		
		float tongDiem = 0;
		for (int i = 0; i < arr.length; i++) {
			tongDiem += arr[i];
		}
		return tongDiem/(arr.length);
	}




	private static void nhapMang(float[] arr) throws NumberFormatException, IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Nhap cac phan tu cho mang: ");
		for (int i = 0; i < arr.length; i++) {			
			System.out.print("Nhap phan tu thu " + (i + 1) + "= ");
			arr[i] = Float.parseFloat(input.readLine());
			while(arr[i] < 0.0 || arr[i] > 10.0){
				System.out.print("Nhap phan tu thu " + (i + 1) + "= ");
				arr[i] = Float.parseFloat(input.readLine());
			}
		}
	}

}
