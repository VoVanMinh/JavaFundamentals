package TestDay2;

import static org.junit.Assert.*;

import org.junit.Test;
import Day2.*;
public class TestCau4 {

	@Test
	public void test() {


		float[] ex = { 0, 0.5f, 0.67f, 0.75f, 0.8f, 0.83f, 0.86f, 0.875f, 0.9f};
		float ac;
		
		for (int i = 0; i < 9; i++) {
			
			float[] arr = new float[i+1];
			for (int j = 0; j < (i+1); j++) {
				arr[i] = i;
			}
			
			ac = Cau4.tinhDTB(arr);
			assertEquals(ex[i], ac, 0.1);
		}
	}

}
