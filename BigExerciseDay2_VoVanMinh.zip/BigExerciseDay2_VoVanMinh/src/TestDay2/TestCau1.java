package TestDay2;

import static org.junit.Assert.*;

import org.junit.Test;
import Day2.*;

public class TestCau1 {

	@Test
	public void test() {
		int[] trongLuong = { 20, 55, 150, 230, 700, 1000, 1500, 1800, 2500, 3000 };
		int[] hinhThuc = { 1, 1, 1, 1, 2, 2, 2, 2, 3, 3 };
		int[] nlt = { 1, 1, 1, 1, 2, 2, 2, 2, 1, 2 };
		int[] chonVung = { 1, 1, 3, 1, 1, 2, 2, 2, 2, 3 };

		double[] ex = { 38500, 38500, 38500, 38500, 70000, 130000, 130000, 130000, 55000, 170000 };
		double ac;
		for (int i = 0; i < 10; i++) {
			ac = Cau1.tinhCuoc(trongLuong[i], hinhThuc[i], nlt[i], chonVung[i]);
			System.out.println(ac);
		}

		for (int i = 0; i < 9; i++) {
			ac = Cau1.tinhCuoc(trongLuong[i], hinhThuc[i], nlt[i], chonVung[i]);
			assertEquals(ex[i], ac, 0);
		}
	}

}
