package bai10_VoVanMinh;

import java.util.Random;
import java.util.Scanner;

public class Cau2 {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
		String nhap = "";
		int soLanChoi = 0;
		int diemPlayer = 0;
		int diemCom = 0;

		while (!nhap.equals("q") && !nhap.equals("Q") && diemCom != 5 && diemPlayer != 5){
			System.out.println("Nhap vao: ");
			nhap = input.nextLine();

			System.out.println("\n------------------------------------------");
			
			TroChoi nc = PlayerNhap(nhap);
			System.out.println("Ban da chon la: " +nc);
			
			TroChoi com = Computer();
			System.out.println("May da chon la: " +com);
			
			soLanChoi++;
			
			if (com == TroChoi.SCISSOR) {

				if (nc == TroChoi.SCISSOR)
					System.out.println("Ngang tai ngang suc.");

				else if (nc == TroChoi.PAPER) {
					System.out.println("Ban thua roi!");
					diemCom++;
				} else if (nc == TroChoi.STONE) {
					System.out.println("Ban da thang!");
					diemPlayer++;
				} else // Nguoi choi chon khac s, p, t
				{
					System.out.println("Ban thua roi!");
					diemCom++;
				}

			}
			else if (com == TroChoi.PAPER) {

				if (nc == TroChoi.SCISSOR) {
					System.out.println("Ban da thang!");
					diemPlayer++;
				}

				else if (nc == TroChoi.PAPER) {

					System.out.println("Ngang tai ngang suc.");

				} else if (nc == TroChoi.STONE) {
					System.out.println("Ban thua roi!");
					diemCom++;
				} else // Nguoi choi chon khac s, p, t
				{
					System.out.println("Ban thua roi!");
					diemCom++;
				}
			}
			else { //(com == TroChoi.STONE) 
				if (nc == TroChoi.SCISSOR) {
					System.out.println("Ban thua roi!");
					diemCom++;
				} else if (nc == TroChoi.PAPER) {
					System.out.println("Ban da thang!");
					diemPlayer++;
				} else if (nc == TroChoi.STONE) {
					System.out.println("Ngang tai ngang suc.");
				} else // Nguoi choi chon khac s, p, t
				{
					System.out.println("Ban thua roi!");
					diemCom++;
				}				
			}
			
			System.out.println("So lan choi la: " +soLanChoi);
			System.out.println("So diem cua ban la: " +diemPlayer);
			System.out.println("So diem cua may la: " +diemCom);

		}
		
		System.out.println("------------------------------------------");
		if(diemPlayer == 5)
			System.out.println("Chuc mung ban da chien thang!");
		else 
			System.out.println("Kaka! Ban da thua roi.");
	}

	public static TroChoi PlayerNhap(String s) {
		switch (s) {
		case "s":
		case "S":
			return TroChoi.SCISSOR;

		case "p":
		case "P":
			return TroChoi.PAPER;

		case "t":
		case "T":
			return TroChoi.STONE;

		default:
			return TroChoi.QUIT;
		}
	}

	public static TroChoi Computer() {
		Random rd = new Random();
		int nhap = rd.nextInt(2);

		switch (nhap) {
		case 0:
			return TroChoi.SCISSOR;
		case 1:
			return TroChoi.PAPER;
		case 2:
			return TroChoi.STONE;
		default:
			return TroChoi.QUIT;
		}
	}

}

enum TroChoi {
	SCISSOR, PAPER, STONE, QUIT;
}
