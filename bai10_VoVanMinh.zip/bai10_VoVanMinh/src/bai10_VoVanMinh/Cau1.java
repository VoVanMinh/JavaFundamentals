package bai10_VoVanMinh;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Cau1 {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
		try {
			System.out.println("Nhap vao x: ");
			float x = input.nextFloat();

			System.out.println("Nhap vao y: ");
			float y = input.nextFloat();

			PhepToan.CONG.tinh(x, y);
			PhepToan.TRU.tinh(x, y);
			PhepToan.NHAN.tinh(x, y);
			PhepToan.CHIA.tinh(x, y);

		} catch (InputMismatchException e) {
			System.out.println("Vui long nhap so.");

		}
	}
}
enum PhepToan {
	CONG, TRU, NHAN, CHIA;

	void tinh(float x, float y) {

		switch(this){
		
		case CONG:  System.out.println(CONG + " la: " + (x + y));
					break;
		case TRU: System.out.println(TRU + " la: " + (x - y));
					break;
		case NHAN: System.out.println(NHAN + " la: " + (x * y));
					break;
		case CHIA: System.out.println(CHIA + " la: " + (x / y));
		try {
			if (y == 0)
				throw new ArithmeticException("Loi chia cho ko");

			System.out.println(CHIA + " la: " + (x / y));
		} catch (ArithmeticException e) {
			System.out.println(e.getMessage());
		}
		System.out.println(Math.sqrt(-5));
	}
	}
}




