package bai10_VoVanMinh;

public class Cau3 {

	public static void main(String[] args) {
		
		for (DenGiaoThong d : DenGiaoThong.values()) {
			System.out.println("Den " +d.name());
			System.out.println("So giay: " +d.getSoGiay());
			System.out.println("Chuyen den den " +d.chenDen());
			System.out.println("-----------------------------------------------");
		}
	}

}
enum DenGiaoThong{
	
	XANH(30){
		public DenGiaoThong chenDen(){
			return VANG;
		}
	},
	DO(30){
		public DenGiaoThong chenDen(){
			return XANH;
		}
	},
	VANG(10){
		public DenGiaoThong chenDen(){
			return DO;
		}
	};
	private final int soGiay;
	private DenGiaoThong (int soGiay)
	{
		this.soGiay = soGiay;
	}
	public int getSoGiay(){
		return soGiay;
	}
	
		
	public abstract DenGiaoThong chenDen();
	
}