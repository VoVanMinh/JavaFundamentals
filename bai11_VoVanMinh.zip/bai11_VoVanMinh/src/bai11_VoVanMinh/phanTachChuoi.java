package bai11_VoVanMinh;

import java.util.Scanner;
import java.util.StringTokenizer;

public class phanTachChuoi {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner nhap = new Scanner(System.in);
		
		
		System.out.print("Nhap vao chuoi ky tu can phan tach: ");
		String chuoi = nhap.nextLine();
		
		System.out.print("\nNhap vao ky tu phan tach: ");
		String kytu = nhap.nextLine();
		
		StringTokenizer st = new StringTokenizer(chuoi, kytu);
		while(st.hasMoreTokens())
		{
			System.out.println(st.nextToken());
		}

	}

}
