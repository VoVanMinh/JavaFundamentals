package bai11_VoVanMinh;

import java.util.Scanner;
import java.util.regex.*;

public class timeFormat {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner nhap = new Scanner(System.in);
		
		System.out.println("Nhap vao thoi gian: ");
		String thoiGian = nhap.nextLine();
		
		String re = "^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$";
		Pattern p = Pattern.compile(re);
		
		Matcher m = p.matcher(thoiGian);
		
		if(m.matches())
			System.out.println("Thoi gian hop le!");
		else 
			System.out.println("Thoi gian khong hop le!");
	}

}
