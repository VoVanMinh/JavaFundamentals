package bai11_VoVanMinh;

import java.util.Scanner;
import java.util.StringTokenizer;

public class phanTachHoTen {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner nhap = new Scanner(System.in);

		System.out.println("Nhap vao chuoi ho ten cua ban: ");
		StringTokenizer hoten = new StringTokenizer(nhap.nextLine());
		try {
			String ho = hoten.nextToken();
			String tenDem = "";
			String ten = "";

			while (hoten.hasMoreTokens()) {
				if (hoten.countTokens() == 1)
					ten = hoten.nextToken();
				else
					tenDem += hoten.nextToken() + " ";
			}

			System.out.println("Ho: " + ho + " \nTen dem: " + tenDem + " \nTen: " + ten);

		} catch (Exception e) {
			System.out.println("Ban nhap sai dinh dang: " + e.getMessage());
		}

	}

}
