package bai11_VoVanMinh;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ImgFileFmt {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner nhap = new Scanner(System.in);
		
		System.out.println("Nhap vao ten tap tin: ");
		String ten = nhap.nextLine();
		//String temp = ten.toLowerCase();
		
		String re = "^[^ ]+[.](?i)(jpg|png|gif|bmp)$";
		Pattern p = Pattern.compile(re);
		
		Matcher m = p.matcher(ten);
		
		if(m.matches())
			System.out.println("Ten file hop le!");
		else 
			System.out.println("Ten file khong hop le!");

	}

}
