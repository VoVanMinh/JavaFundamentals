package bai11_VoVanMinh;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class usernameFormat {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner nhap = new Scanner(System.in);
		
		System.out.println("Nhap vao username: ");
		String userName = nhap.nextLine();
		
		String re = "^[a-z0-9_-]{6,20}$";
		Pattern p = Pattern.compile(re);
		
		Matcher m = p.matcher(userName);
		
		if(m.matches())
			System.out.println("Username hop le!");
		else 
			System.out.println("Username khong hop le!");

	}

}
