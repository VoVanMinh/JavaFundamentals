package bai11_VoVanMinh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Cau1 {

	public static void main(String[] args) throws IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		
		try{
		System.out.print("Nhap vao chuoi s1: ");
		String s1 = input.readLine();
		
		System.out.print("Nhap vao chuoi s2: ");
		String s2 = input.readLine();
		
		System.out.print("Nhap vao chuoi s3: ");
		String s3 = input.readLine();
		
		System.out.print("Nhap vao vi tri: ");
		int vt = Integer.parseInt(input.readLine());
		
		
		System.out.println("\nChieu dai chuoi s1: " +s1.length());
		System.out.println("Chieu dai chuoi s2: " +s2.length());
		System.out.println("Chieu dai chuoi s3: " +s3.length());
		System.out.println("Ket qua so s1 & s2: " +s1.compareTo(s2));
		System.out.println("Vi tri xuat hien dau tien cua s3 trong s1 la: " +s1.indexOf(s3));
		String s4 = s1.substring(vt);
		System.out.println("Chuoi s4: " +s4);
		
		}catch (NumberFormatException e) {
			System.out.println("Vui long nhap vao so.");
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
