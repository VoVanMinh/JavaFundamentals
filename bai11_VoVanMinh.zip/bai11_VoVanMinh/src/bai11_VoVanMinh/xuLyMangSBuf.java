package bai11_VoVanMinh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class xuLyMangSBuf {

	public static void main(String[] args) throws IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.print("Nhap vao chuoi nguon sb: ");
		StringBuilder sb = new StringBuilder(input.readLine());
		
		System.out.println("Cac ki tu cua chuoi sb la: ");
		for (int i = 0; i < sb.length(); i++) {
			System.out.println(sb.charAt(i));
		}
		
		System.out.print("Nhap vao chuoi kt: ");
		StringBuilder kt = new StringBuilder(input.readLine());
		timChuoi(sb, kt);

	}

	private static void timChuoi(StringBuilder sb, StringBuilder kt) {
		int temp = sb.indexOf(kt.toString());
		if (temp == -1)
			System.out.println("Khong tim thay chuoi kt.");
		else
		{
			while(temp != -1){
				System.out.println("Vi tri cua kt trong sb la: " +temp);
				temp = sb.indexOf(kt.toString(), (temp+1));
			}
		}
	}

}
