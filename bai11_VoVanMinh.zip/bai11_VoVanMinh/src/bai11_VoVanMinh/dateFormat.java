package bai11_VoVanMinh;

import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class dateFormat {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner nhap = new Scanner(System.in);

		System.out.println("Nhap vao date: ");
		String date = nhap.nextLine();

		String re = "^([0-9]|0[0-9]|[1-2][0-9]|3[0-1])[/]([0-9]|0[0-9]|1[0-2])[/](19[0-9][0-9]|[2-9][0-9][0-9][0-9])$";
		Pattern p = Pattern.compile(re);
		Matcher m = p.matcher(date);

		if (!m.matches())
			System.out.println("Date khong hop le!");
		else {

			StringTokenizer st = new StringTokenizer(date, "/");
			int ng = Integer.parseInt(st.nextToken());
			int th = Integer.parseInt(st.nextToken());
			int nam = Integer.parseInt(st.nextToken());

			if (checkDate(ng, th, nam))
				System.out.println("Date hop le!");
			else
				System.out.println("Date khong hop le!");
		}
	}

	private static boolean checkDate(int ng, int th, int nam) {
			if (th == 4 || th == 6 || th == 9 || th == 11) {
				if (ng == 31)
					return false;
			}

			else if (th == 2) {
				if ((nam % 400 == 0) || (nam % 4 == 0 && nam % 100 != 0)) {
					if (ng > 29)
						return false;
					
				} else {
					if (ng > 28)
						return false;
					}
				}
		return true;
	}
}
