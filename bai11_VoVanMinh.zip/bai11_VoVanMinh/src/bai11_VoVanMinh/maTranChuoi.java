package bai11_VoVanMinh;

import java.util.InputMismatchException;
import java.util.Scanner;

public class maTranChuoi {

	public static void main(String[] args) {
		String[][] maTran;
		int chon = 10;
		
		do{
		@SuppressWarnings("resource")
		Scanner nhap = new Scanner(System.in);
		try{
		System.out.print("Nhan 0 de thoat! Nhap vao so tu 1 -> 9: ");
		chon = nhap.nextInt();
		}catch (InputMismatchException e) {
			System.out.println("Vui long nhap vao so.");
		}
		switch (chon) {
		case 1:
			maTran = maTranA();
			xuLyNull(maTran);
			xuatMaTran(maTran);
			break;
		case 2:
			maTran = maTranB();
			xuLyNull(maTran);
			xuatMaTran(maTran);
			break;
		case 3:
			maTran = maTranC();
			xuLyNull(maTran);
			xuatMaTran(maTran);
			break;
		case 4:
			maTran = maTranD();
			xuLyNull(maTran);
			xuatMaTran(maTran);
			break;
		case 5:
			maTran = maTranE();
			xuLyNull(maTran);
			xuatMaTran(maTran);
			break;
		case 6:
			maTran = maTranF();
			xuLyNull(maTran);
			xuatMaTran(maTran);
			break;
		case 7:
			maTran = maTranG();
			xuLyNull(maTran);
			xuatMaTran(maTran);
			break;
		case 8:
			maTran = maTranH();
			xuLyNull(maTran);
			xuatMaTran(maTran);
			break;
		case 9:
			maTran = maTranI();
			xuLyNull(maTran);
			xuatMaTran(maTran);
			break;
		default:
			break;
		}
		}while(chon != 0);
	}

	private static String[][] maTranI() {
		String[][] maTran = new String[7][7];
		for (int i = 0; i < maTran.length; i++) {
			maTran[0][i] = "#";
			maTran[6][i] = "#";
			maTran[i][6 - i] = "#";
			maTran[i][i] = "#";
			maTran[i][0] = "#";
			maTran[i][6] = "#";
		}
		return maTran;
	}

	private static String[][] maTranH() {
		String[][] maTran = new String[7][7];
		for (int i = 0; i < maTran.length; i++) {
			maTran[0][i] = "#";
			maTran[6][i] = "#";
			maTran[i][6 - i] = "#";
			maTran[i][i] = "#";
		}
		return maTran;

	}

	private static String[][] maTranG() {
		String[][] maTran = new String[7][7];
		for (int i = 0; i < maTran.length; i++) {
			maTran[0][i] = "#";
			maTran[6][i] = "#";
			maTran[i][6 - i] = "#";
		}
		return maTran;
	}

	private static String[][] maTranF() {
		String[][] maTran = new String[7][7];
		for (int i = 0; i < maTran.length; i++) {
			maTran[0][i] = "#";
			maTran[6][i] = "#";
			maTran[i][i] = "#";
		}
		return maTran;
	}

	private static void xuLyNull(String[][] maTran) {
		for (int i = 0; i < maTran.length; i++) {
			for (int j = 0; j < maTran[0].length; j++) {
				if (maTran[i][j] == null)
					maTran[i][j] = " ";
			}
		}

	}

	private static String[][] maTranE() {
		String[][] maTran = new String[7][7];
		for (int i = 0; i < 7; i += 6) {
			for (int j = 0; j < 7; j++) {
				maTran[i][j] = "#";
			}
		}

		for (int i = 1; i < 6; i++) {
			maTran[i][0] = "#";
			maTran[i][6] = "#";
		}
		return maTran;
	}

	private static String[][] maTranD() {
		String[][] maTran = new String[8][8];
		int a = 7;
		for (int i = 0; i <= 7; i++) {
			for (int j = 7; j >= a; j--) {
				maTran[i][j] = "#";
			}
			a--;
		}
		return maTran;
	}

	private static String[][] maTranC() {
		String[][] maTran = new String[8][8];
		for (int i = 0; i <= 7; i++) {
			for (int j = i; j <= 7; j++) {
				maTran[i][j] = "#";
			}
		}
		return maTran;
	}

	private static String[][] maTranB() {
		String[][] maTran = new String[8][8];
		int a = 8;
		for (int i = 0; i < maTran.length; i++) {
			for (int j = 0; j < a; j++) {
				maTran[i][j] = "#";
			}
			a--;
		}
		return maTran;
	}

	private static String[][] maTranA() {
		String[][] maTran = new String[8][8];
		for (int i = 0; i < maTran.length; i++) {
			for (int j = 0; j <= i; j++) {
				maTran[i][j] = "#";
			}
		}
		return maTran;

	}

	private static void xuatMaTran(String[][] maTran) {
		for (int i = 0; i < maTran.length; i++) {
			for (int j = 0; j < maTran[0].length; j++) {
				if (maTran[i][j] != null)
					System.out.print(maTran[i][j]);
			}
			System.out.print("\n");
		}

	}

}
