package bai11_VoVanMinh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class xuLyMangChuoi {

	public static void main(String[] args) {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		try {
			int n;
			do {

				System.out.println("Nhap vao so nguyen duong: ");
				n = Integer.parseInt(input.readLine());
			} while (n < 1);

			String[] mangTen = new String[n];
			nhapMang(mangTen);
			xuatMang(mangTen);

			System.out.print("\nNhap vao ten mot nguoi: ");
			String ten = input.readLine();

			kiemTraTen(mangTen, ten);
			timKiTu(mangTen);
			
			Arrays.parallelSort(mangTen);
			xuatMang(mangTen);
			
		} catch (NumberFormatException e) {
			System.out.println("Vui long nhap vao so.");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	private static void timKiTu(String[] mangTen) {
		System.out.println("Nhung phan tu co ki tu n trong mang la: ");
		for (String i : mangTen) {
			if(i.contains("n"))
			{
				System.out.println(i +" \t");
			}
		}
		
	}

	private static void kiemTraTen(String[] mangTen, String ten) {
		for (int i = 0; i < mangTen.length; i++) {
			if (ten.equalsIgnoreCase(mangTen[i])) {
				System.out.println(ten + "xuat hien o vi tri: " + (i + 1));
				return;
			}
		}
		System.out.println(ten + "khong cuat hien trong mang.");
	}

	private static void xuatMang(String[] mangTen) {
		System.out.println("Mang la: ");
		for (String string : mangTen) {
			System.out.print(string + "\t");
		}

	}

	private static void nhapMang(String[] mangTen) throws IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		for (int i = 0; i < mangTen.length; i++) {
			System.out.print("\nNhap vao phan tu thu " + (i + 1) + ": ");
			mangTen[i] = input.readLine();
		}

	}

}
