package bai11_VoVanMinh;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class emailFormat {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner nhap = new Scanner(System.in);

		System.out.println("Nhap vao email: ");
		String email = nhap.nextLine();

		String re = "^([_a-zA-Z0-9-\\+]+([.][_a-zA-Z0-9-]+)*)@[a-zA-Z0-9-]+[.]([a-zA-Z0-9]{2,})(([.]([a-zA-Z]{2,}))*)$";
		Pattern p = Pattern.compile(re);
		Matcher m = p.matcher(email);

		if (m.matches())
			System.out.println("Email hop le!");
		else 
			System.out.println("Email khong hop le!");

	}

}
