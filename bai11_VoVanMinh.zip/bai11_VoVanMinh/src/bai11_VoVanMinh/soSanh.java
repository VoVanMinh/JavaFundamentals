package bai11_VoVanMinh;


public class soSanh {

	public static void main(String[] args) {
		
		long t1 = System.currentTimeMillis();
		String s = "" ;
		StringBuilder sb = new StringBuilder();
		
		for (int i = 1; i <= 10000; i++) {
			s += i+ " ";
		}
		System.out.println("Chieu dai chuoi String la: " +s.length() );
		long t2 = System.currentTimeMillis();
		
		for (int i = 1; i <= 10000; i++) {
			sb.append(i + " ");
		}
		System.out.println("Chieu dai chuoi StringBuilder la: " +sb.length() );
		long t3 = System.currentTimeMillis();
		
		System.out.println("Thoi gian thuc hien cua String la: " +(t2 - t1));
		System.out.println("Thoi gian thuc hien cua String la: " +(t3 - t2));
		
	}

}
