package bai11_VoVanMinh;

public class soSanh2 {

	public static void main(String[] args) {
		long t1 = System.currentTimeMillis();
		
		StringBuilder sb1 = new StringBuilder() ;		
		for (int i = 0; i < 10000; i++) {
			sb1.append('A');
		}
		System.out.println("Chieu dai chuoi Sb1 la: " +sb1.length() );
		long t2 = System.currentTimeMillis();
		
		StringBuilder sb2 = new StringBuilder();
		for (int i = 0; i < 10000; i++) {
			sb2.append("A");
		}
		System.out.println("Chieu dai chuoi Sb2 la: " +sb2.length() );
		long t3 = System.currentTimeMillis();
		
		System.out.println("Thoi gian thuc hien cua Sb1 la: " +(t2 - t1));
		System.out.println("Thoi gian thuc hien cua Sb2 la: " +(t3 - t2));

	}

}
