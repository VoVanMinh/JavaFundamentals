package bai11_VoVanMinh;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Cau2 {

	public static void main(String[] args) {

		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		try {

			System.out.print("Nhap chuoi nguon sb: ");
			StringBuilder sb = new StringBuilder(input.readLine());

			System.out.print("Nhap chuoi sb1: ");
			StringBuilder sb1 = new StringBuilder(input.readLine());

			System.out.print("Nhap chuoi sb2: ");
			StringBuilder sb2 = new StringBuilder(input.readLine());

			System.out.print("Nhap chuoi sb3: ");
			StringBuilder sb3 = new StringBuilder(input.readLine());

			System.out.print("Nhap chuoi sb4: ");
			StringBuilder sb4 = new StringBuilder(input.readLine());

			System.out.println("Nhap vi tri chen: ");
			int vtch = Integer.parseInt(input.readLine());
			
			System.out.println("Nhap vi tri dau: ");
			int vtd = Integer.parseInt(input.readLine());
			
			System.out.println("Nhap vi tri cuoi: ");
			int vtc = Integer.parseInt(input.readLine());

			System.out.println("Chieu dai chuoi sb1: " +sb1.length());
			System.out.println("Chieu dai chuoi sb2: " +sb2.length());
			System.out.println("Chieu dai chuoi sb3: " +sb3.length());
			System.out.println("Chieu dai chuoi sb4: " +sb4.length());
			
			sb.append(sb1);
			System.out.println("Chuoi sb: " +sb);
			
			sb.insert(vtch, sb2);
			System.out.println("Chuoi sb: " +sb);
			
			sb.delete(vtd, vtc);
			System.out.println("Chuoi sb: " +sb);
			
			sb.reverse();
			System.out.println("Chuoi sb: " +sb);
			
		} catch (NumberFormatException e) {
			System.out.println("Vui long nhap vao so.");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

}
