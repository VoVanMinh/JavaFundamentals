package bai11_VoVanMinh;

import java.util.Scanner;
import java.util.StringTokenizer;

public class phanTachDate {

	public static void main(String[] args) {

		@SuppressWarnings("resource")
		Scanner nhap = new Scanner(System.in);

		System.out.println("Nhap vao chuoi ngay - thang - nam: ");
		StringTokenizer ntn = new StringTokenizer(nhap.nextLine(), "-");

		try {
			String ngay = ntn.nextToken();
			String thang = ntn.nextToken();
			String nam = ntn.nextToken();

			System.out.println("Ngay: " + ngay + " Thang: " + thang + " Nam: " + nam);
		} catch (Exception e) {
			System.out.println("Ban nhap sai dinh dang: " + e.getMessage());
		}

	}

}
