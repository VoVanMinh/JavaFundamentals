package bai3_VoVanMinh;

public class Cau4 {
	public static void main(String[] args) {
		int re = +1;
		System.out.println(re);
		
		re--;
		System.out.println(re);
		
		re++;
		System.out.println(re);
		
		re = -re;
		System.out.println(re);
		
		boolean su = false;
		System.out.println(su);
		System.out.println(!su);
	}
}
