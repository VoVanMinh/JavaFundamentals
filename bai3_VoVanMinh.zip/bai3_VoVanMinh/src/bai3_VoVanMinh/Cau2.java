package bai3_VoVanMinh;

public class Cau2 {

	public static void main(String[] args) {
		int re = 1 + 2;
		System.out.println("1 + 2 = " +re);
		
		int or = re;
		re = re - 1;
		System.out.println(or+ " -1 = " +re);
		
		or = re;
		re = re * 2;
		System.out.println(or+ "*2 =" +re);
		
		or = re;
		re = re/2;
		System.out.println(or + "/2 = " +re);
		or = re;
		
		re = re +8;
		System.out.println(or+ " +8 = " +re);
		
		or = re;
		re =re%7;
		System.out.println(or+ " %7 = " +re);

	}

}
