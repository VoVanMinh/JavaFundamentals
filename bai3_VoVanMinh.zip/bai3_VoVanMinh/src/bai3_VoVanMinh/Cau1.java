package bai3_VoVanMinh;

import java.util.Scanner;

public class Cau1 {

	public static void main(String[] args) {
		try
		{
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			
			System.out.print("Nhap vao x: ");
			int x = sc.nextInt();
			
			//float g = (float) Math.pow(x, 3);
			float S = 1 + x + x*x*x/3 + x*x*x*x*x/5;
			System.out.println("Tong la: " +S);
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
	}

}
