package bai3_VoVanMinh;

public class Cau6 {

	public static void main(String[] args) {
		int x =10;
		int y = 4;
		
		boolean eq = x == y;
		System.out.println("x==y is " +eq);
		
		boolean ne = x != y;
		System.out.println("x!=y is " +ne);
		
		boolean lt = x < y;
		System.out.println("x<y is " +lt);
		
		boolean gt = x > y;
		System.out.println("x>y is " +gt);
		
		boolean le = x <= y;
		System.out.println("x<=y is " +le);
		
		boolean ge = x >= y;
		System.out.println("x>=y is " +ge);
		
		

	}

}
