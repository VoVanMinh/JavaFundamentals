package bai7_VoVanMinh;

import java.util.Scanner;

public class Cau6_2 {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);

		System.out.println("Nhap vao n: ");
		int n = input.nextInt();

		System.out.println("Ket qua A = " + tinhA(n));
		System.out.println("Ket qua B = " + tinhB(n));
		System.out.println("Ket qua C = " + tinhC(n));
		System.out.println("Ket qua D = " + tinhD(n));
	}

	private static int tinhA(int n) {
		int A = 0;
		for (int i = 1; i <= n; i++) {
			if (i % 2 == 0)
				A += i;
		}
		return A;
	}

	private static int tinhB(int n) {
		int B = 0;
		for (int i = 1; i <= n; i++) {
			if (i % 2 == 1)
				B += i;
		}
		return B;
	}

	public static float tinhC(int n) {
		if(n < 1)
			return 0;
		int C = 1;
		for (int i = 1; i <= n; i++) {
			C *= i;
		}
		return C;
	}

	private static int tinhD(int n) {
		if(n < 1)
			return 0;
		int D = 1;
		for (int i = 1; i <= n; i++) {
			if (i % 3 == 0)
				D *= i;
		}
		return D;
	}

}
