package bai7_VoVanMinh;

import java.util.Scanner;

public class Cau6_3 {

	public static void main(String[] args) {

		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);

		System.out.println("Nhap vao so thap phan n: ");
		int n = input.nextInt();

		System.out.println(doi10to2(n));
	}

	public static String doi10to2(int n) {
		StringBuilder sb = new StringBuilder("");
		if(n <= 0)
			return "0".toString();
		while (n != 0) {
			sb.append((n % 2));
			n = n / 2;
		}
		sb.reverse();
		return sb.toString();
	}
}
