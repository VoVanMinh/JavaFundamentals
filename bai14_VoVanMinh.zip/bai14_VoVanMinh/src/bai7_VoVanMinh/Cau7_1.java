package bai7_VoVanMinh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

public class Cau7_1 {

	public static void main(String[] args) throws NumberFormatException, IOException {

		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Nhap n: ");
		int n = Integer.parseInt(input.readLine());

		int[] a = new int[n];

		mangNgauNhien(a);
		xuatMang(a);
		System.out.println("\nTong la: " + sum(a));
	}

	public static int sum(int[] a) {
		int sum = 0;
		for (int i = 0; i < a.length; i++) {
			sum += a[i];
		}
		return sum;
	}

	private static int[] mangNgauNhien(int[] a) {
		Random random = new Random();
		for (int i = 0; i < a.length; i++) {
			a[i] = random.nextInt(10);
		}
		return a;
	}

	private static void xuatMang(int[] a) {
		System.out.println("Mang ngau nhien: ");
		for (int i = 0; i < a.length; i++) {
			System.out.print(a[i] + " ");
		}

	}

}
