package bai7_VoVanMinh;

import java.util.Scanner;

public class Cau6_1 {

	public static void main(String[] args) {
		
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);

		System.out.println("Nhap vao x: ");
		int x = input.nextInt();
		if(laNguyenTo(x))
			System.out.println(x + " la so nguyen to");
		else
			System.out.println(x + " khong phai la so nguyen to");		
	}

	public static boolean laNguyenTo(int x) {
		if(x < 2)
			return false;
		int c = (int) Math.sqrt(x);
		for (int i = 2; i <= c; i++) {
			if (x % i == 0) {
				return false;
			}
		}		
		return true;
	}

}
