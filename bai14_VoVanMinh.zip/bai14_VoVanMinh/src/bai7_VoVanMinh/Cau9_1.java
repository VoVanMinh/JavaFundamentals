package bai7_VoVanMinh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Cau9_1 {
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		try {
			int n;
			do {
				System.out.println("Nhap vao n >=1: ");
				n = Integer.parseInt(input.readLine());
			} while (n < 1);

			int[] a = new int[n];

			nhapMang(a);
			xuatMang(a);

			if (tangDan(a))
				System.out.println("\nMang nay tang dan.");
			else
				System.out.println("\nMang nay khong tang dan.");

			if (giamDan(a))
				System.out.println("Mang nay giam dan.");
			else
				System.out.println("Mang nay khong giam dan.");

			timPhanTu6(a);

		} catch (NumberFormatException e) {
			System.out.println("Vui long nhap vao so");
		}

	}

	private static void timPhanTu6(int[] a) {
		for (int i = 0; i < a.length; i++) {
			if (a[i] % 10 == 6) {
				System.out.println("Tim thay phan tu co tan cung la 6 o vi tri: " + i);
				System.out.println("Gia tri la: " + a[i]);
			}
		}

	}

	public static boolean tangDan(int[] a) {
		for (int i = 0; i < a.length - 1; i++) {
			if (a[i] > a[i + 1]) {
				return false;
			}
		}
		return true;
	}

	private static boolean giamDan(int[] a) {
		for (int i = 0; i < a.length - 1; i++) {
			if (a[i] < a[i + 1]) {
				return false;
			}
		}
		return true;
	}

	private static void nhapMang(int[] a) throws NumberFormatException, IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Nhap cac phan tu cho mang: ");
		for (int i = 0; i < a.length; i++) {
			System.out.print("Nhap phan tu thu " + (i + 1) + "= ");
			a[i] = Integer.parseInt(input.readLine());
		}
	}

	private static void xuatMang(int[] a) {
		System.out.print("Mang da nhap: ");
		for (int i = 0; i < a.length; i++) {
			System.out.print(a[i] + " ");
		}

	}

}
