package Test;

import static org.junit.Assert.*;

import org.junit.Test;
import bai7_VoVanMinh.*;

public class TestCau4 {

	@Test
	public void test() {
		int[] year = { 1990, 1991, 1992, 1993, 1994, 1995, 
				2012, 2014, 2015, 2016 };
		String[] ex = {"Canh Ngo", "Tan Mui", "Nham Than", "Quy Dau",
				"Giap Tuat", "At Hoi", "Nham Thin", "Giap Ngo", "At Mui", "Binh Than"};
		String ac;
		
		for (int i = 0; i < 10; i++) {
			ac = Cau4.tinhNamAmLich(year[i]);
			assertEquals(ex[i], ac);
		}
	}

}
