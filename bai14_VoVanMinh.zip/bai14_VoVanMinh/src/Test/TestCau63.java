package Test;

import static org.junit.Assert.*;

import org.junit.Test;
import bai7_VoVanMinh.*;

public class TestCau63 {

	@Test
	public void test() {
		int[] n = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 10 };
		String[] ex = { "0", "1", "10", "11", "100", "101", "110", "111", "1000", "1010" };

		String ac;
		for (int i = 0; i < 10; i++) {
			ac = Cau6_3.doi10to2(n[i]);
			assertEquals(ex[i], ac);
		}

	}

}
