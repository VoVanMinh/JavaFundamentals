package Test;

import static org.junit.Assert.*;


import org.junit.Test;
import bai7_VoVanMinh.*;

public class TestCau73 {

	@Test
	public void test() {
		float ac;
		int[][] arr = null;

		float[] ex = { 0, 0, 1, 1, 2, 2, 3, 3, 4, 4 };
		for (int i = 0; i < 10; i++) {
			arr = new int[i + 1][2];
			for (int j = 0; j <= i; j++) {
				arr[j][0] = j;
				arr[j][1] = j;
			}
			ac = Cau7_3.tbinhChan(arr);
			assertEquals(ex[i], ac, 0);

		}
	}
}
