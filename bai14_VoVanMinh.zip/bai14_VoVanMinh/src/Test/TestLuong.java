package Test;

import static org.junit.Assert.*;

import org.junit.Test;
import Code.Luong;

public class TestLuong {

	@Test
	public void test() {

		double[] heSoLuong = { 2.34, 3, 3.33, 3.66, 3.99, 2.22, 2.04, 2.67, 4.22, 4.55 };
		double luongCoBan = 1150000;
		double[] troCap = { 100000, 150000, 200000, 300000, 400000, 100000, 150000, 200000, 500000, 300000 };
		double[] thuong = { 250000, 250000, 300000, 300000, 350000, 150000, 150000, 250000, 450000, 500000 };
		double[] ex = { 3041000, 3850000, 4329500, 4809000, 5338500, 2803000, 2646000, 3520500, 5803000, 6032500 };
		double ac = 0;

		
		for (int i = 0; i < 10; i++) {
			ac = Luong.tinhLuong(heSoLuong[i], luongCoBan, troCap[i], thuong[i]);
			assertEquals(ex[i], ac, 0);
		}

	}

}
