package Test;

import static org.junit.Assert.*;

import org.junit.Test;
import bai7_VoVanMinh.*;
public class TestCau71 {

	@Test
	public void test() {
		int[] ex = {0,1,3,6,10,15,21,28,36,45};
		int ac;
		int [] a = new int[10];
		
		for (int i = 0; i < 10; i++) {
			a[i] = i;
			ac = Cau7_1.sum(a);
			assertEquals(ex[i], ac);
			
		}
		
	}

}
