package Test;

import static org.junit.Assert.*;

import org.junit.Test;

import Code.TamGiac;

public class TestTamGiac {

	@Test
	public void test() {
		int[] a = { 1, 2, 3, 4, 10, 1, 2, 5, 6, 2 };
		int[] b = { 2, 3, 1, 5, 5, 1, 1, 10, 3, 4 };
		int[] c = { 4, 4, 5, 6, 20, 1, 4, 8, 10, 5 };

		boolean ac;

		for (int i = 0; i < 10; i++) {
			ac = TamGiac.laTamGiac(a[i], b[i], c[i]);

			// console
			if (!ac) {
				System.out.println("Sai o vi tri: " + (i + 1));
			}
		}
		for (int i = 0; i < 10; i++) {
			// JUnit
			ac = TamGiac.laTamGiac(a[i], b[i], c[i]);
			if((i % 2) == 0)
				assertFalse(ac);
			else 
				assertTrue(ac);
		}

	}

}
