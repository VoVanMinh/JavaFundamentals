package Test;

import static org.junit.Assert.*;



import org.junit.Test;
import bai7_VoVanMinh.*;
public class TestCau91 {

	@Test
	public void test() {
		int[] a = new int[10];
		boolean ac;
		
		for (int i = 9; i >= 0; i--) {
			
			if (i > 5)
				a[i] = i;
			else
				a[i] = 10 - i;
			
			ac = Cau9_1.tangDan(a);
			
			if(i > 4)
				assertTrue(ac);
			else
				assertFalse(ac);
		}
	}

}
