package Test;

import static org.junit.Assert.*;

import org.junit.Test;
import Code.PhuongTrinhBac2;


public class TestPTBac2 {

	@Test
	public void test() {

		float[] a = { 0, 0, 0, 0, 1, 1, 1, 1, 1, 1 };
		float[] b = { 0, 0, 1, 1, 0, 0, 1, 5, 5, 5 };
		float[] c = { 0, 1, 0, 1, 0, 1, 1, 1, 2, 3 };
		String[] ex = { "Vo so nghiem", "Vo nghiem", "0.000", "-1.000", "0.000", "Vo nghiem", "Vo nghiem",
				"-0.209; -4.791", "-0.438; -4.562", "-0.697; -4.303" };
		String ac;

		for (int i = 0; i < 10; i++) {
			ac = PhuongTrinhBac2.giaiPTBac2(a[i], b[i], c[i]);

			// console
			if (!ex[i].equals(ac)) {
				System.out.println("Sai o vi tri: " + (i + 1));
				System.out.println("Gia tri thuc te la: " + ac);
			}
		}
		for (int i = 0; i < 10; i++) {
			// JUnit
			ac = PhuongTrinhBac2.giaiPTBac2(a[i], b[i], c[i]);
			assertEquals(ex[i], ac);
		}

	}

}
