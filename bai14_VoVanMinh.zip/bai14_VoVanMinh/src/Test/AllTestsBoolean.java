package Test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TestCau61.class, TestCau72.class, TestCau91.class, TestTamGiac.class })
public class AllTestsBoolean {

}
