package Test;

import static org.junit.Assert.*;

import org.junit.Test;
import bai7_VoVanMinh.*;

public class TestCau61 {

	@Test
	public void test() {

		int[] x = { -1, 0, 1, 4, 6, 8, 2, 3, 5, 7 };
		
		boolean ac;

		for (int i = 0; i < 10; i++) {
			ac = Cau6_1.laNguyenTo(x[i]);
			if(i < 6)
				assertFalse(ac);
			else 
				assertTrue(ac);
		}

	}

}
