package Test;

import static org.junit.Assert.*;

import org.junit.Test;
import bai7_VoVanMinh.Cau1;

public class TestCau1 {

	@Test
	public void test() {
		float[] x = { -1, -1, -1, 0, 0, 0, 1, 1, 1, 5 };
		int[] n = { -1, 1, 0, -1, 0, 1, -1, 0, 1, 2 };
		float[] ex = {0.5f, 2, 1, 1, 1, 1, 0.5f, 1, 2, 676};

		float ac;

		for (int i = 0; i < 10; i++) {
			ac = Cau1.tinhS(x[i], n[i]);

			// console
			if (ex[i] != ac) {
				System.out.println("Sai o vi tri: " + (i + 1));
				System.out.println("Gia tri thuc te la: " + ac);
			}
		}
		for (int i = 0; i < 10; i++) {
			// JUnit
			ac = Cau1.tinhS(x[i], n[i]);
			assertEquals(ex[i], ac, 0);
		}
	}

}
