package Test;

import static org.junit.Assert.*;

import org.junit.Test;

import Code.BMI;

public class TestBMI {
	@Test
	public void test1() {
		float[] canNang = { 45, 50, 55, 60, 65, 30, 34, 40, 25, 20 };
		float[] chieuCao = { 1.55f, 1.6f, 1.65f, 1.7f, 1.75f, 1.5f, 1.45f, 1.4f, 1.35f, 1.3f };
		float[] ex = { 18.73f, 19.53125f, 20.20f, 20.761246f, 21.22f, 13.333333f, 16.17f, 20.41f, 13.71f, 11.83432f };
		float ac;
		for (int i = 0; i < 10; i++) {
			ac = BMI.tinhbMI(canNang[i], chieuCao[i]);

			// Console
			float a = (Math.round(ac * 100));
			float b = (Math.round(ex[i] * 100));
			if (Math.abs(a - b) > 1) {
				System.out.println("Sai o vi tri: " + (i + 1));
				System.out.println("Gia tri thuc te la: " + (ac));
			}
		}
		for (int i = 0; i < 10; i++) {
			// JUnit
			ac = BMI.tinhbMI(canNang[i], chieuCao[i]);
			assertEquals(ex[i], ac, 0.01);

		}

	}

}
