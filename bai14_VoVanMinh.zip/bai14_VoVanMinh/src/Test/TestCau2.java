package Test;

import static org.junit.Assert.*;

import org.junit.Test;
import bai7_VoVanMinh.*;
public class TestCau2 {

	@Test
	public void test() {
		float[] x = { -1, -1, -1, 0, 0, 0, 1, 1, 1, 5 };
		int[] n = { -1, 1, 0, -1, 0, 1, -1, 0, 1, 2 };
		float[] ex = {1.33f, 4, 2, 2, 2, 2, 1.33f, 2, 4, 1402};

		float ac;

		// JUnit
		for (int i = 0; i < 10; i++) {
			ac = Cau2.tinhS(x[i], n[i]);
			assertEquals(ex[i], ac, 0.1);
		}
	}

}
