package Test;

import static org.junit.Assert.*;

import org.junit.Test;
import bai7_VoVanMinh.*;

public class TestCau82 {

	@Test
	public void test() {
		int[] n = { 0, 1, 10, 11, 100, 101, 110, 111, 1000, 1001 };
		int ac;
		for (int i = 0; i < 10; i++) {
			ac = Cau8_2.doi2den10(n[i]);
			assertEquals(i, ac);
		}
	}

}
