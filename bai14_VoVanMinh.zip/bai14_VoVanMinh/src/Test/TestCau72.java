package Test;

import static org.junit.Assert.*;

import org.junit.Test;
import bai7_VoVanMinh.*;

public class TestCau72 {

	@Test
	public void test() {
		
		boolean ac;
		int[] a = new int[10];

		for (int i = 0; i < 10; i++) {
			a[i] = i;
			ac = Cau7_2.isMax(5, a);
			if(i < 6)
				assertTrue(ac);
			else 
				assertFalse(ac);

		}
	}

}
