package Test;

import static org.junit.Assert.*;

import org.junit.Test;
import bai7_VoVanMinh.*;
public class TestCau3 {

	@Test
	public void test() {
		
		int[] a = new int[10];
		
		int ac;

		for (int i = 0; i < 10; i++) {
			a[i] = i;
			ac = Cau3.timX(5, a);
			if(i < 5)
				assertEquals(-1, ac, 0);
			else
				assertEquals(6, ac, 0);
		}
	}

}
