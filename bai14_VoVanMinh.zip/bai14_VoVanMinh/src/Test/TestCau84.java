package Test;

import static org.junit.Assert.*;

import org.junit.Test;
import bai7_VoVanMinh.*;

public class TestCau84 {

	@Test
	public void test() {
		int[] n = { -1, 0, 1, 2, 3, 4, 5, 6, 7, 8 };
		int[] ex = { 0, 0, 1, 2, 3, 8, 15, 48, 105, 384 };
		int ac;

		for (int i = 0; i < 10; i++) {
			ac = Cau8_4.tinh2GThua(n[i]);
			assertEquals(ex[i], ac);
		}
	}

}
