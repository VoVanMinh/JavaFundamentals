package Test;

import static org.junit.Assert.*;

import org.junit.Test;
import bai7_VoVanMinh.*;

public class TestCau81 {

	@Test
	public void test() {
		int[] n = { -1, 0, 1, 2, 3, 4, 5, 6, 7, 8 };
		int[] ex = { 0, 0, 0, 2, 5, 5, 10, 10, 17, 17 };
		int ac;
		for (int i = 0; i < 10; i++) {
			ac = Cau8_1.tinhE(n[i]);
			assertEquals(ex[i], ac);
		}
	}

}
