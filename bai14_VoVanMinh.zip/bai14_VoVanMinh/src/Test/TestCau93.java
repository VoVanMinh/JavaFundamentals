package Test;

import static org.junit.Assert.*;

import org.junit.Test;
import bai7_VoVanMinh.*;

public class TestCau93 {

	@Test
	public void test() {
		float ac;
		int[][] arr = null;
		float[] ex = { 0, 1, 3, 6, 10, 15, 21, 28, 36, 45 };

		for (int i = 0; i < 10; i++) {
			arr = new int[i + 1][i + 1];
			for (int j = 0; j <= i; j++) {
				arr[j][j] = j;
			}

			ac = Cau9_3.DCC(arr);
			assertEquals(ex[i], ac, 0);

		}
	}

}
