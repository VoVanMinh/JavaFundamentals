package Test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TestBMI.class, TestCau1.class, TestCau2.class, TestCau3.class, TestCau4.class,
		TestCau62.class, TestCau63.class, TestCau71.class, TestCau73.class, TestCau81.class,
		TestCau82.class, TestCau84.class, TestCau93.class, TestLuong.class, TestPTBac2.class })
public class AllTestsEquals {
	
}
