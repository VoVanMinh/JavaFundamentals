package Test;

import static org.junit.Assert.*;

import org.junit.Test;
import bai7_VoVanMinh.*;

public class TestCau62 {

	@Test
	public void test() {
		int[] n = { -1, 0, 1, 2, 3, 4, 5, 6, 7, 10 };
		float[] ex = { 0, 0, 1, 2, 6, 24, 120, 720, 5040, 3628800 };

		float ac;
		for (int i = 0; i < 10; i++) {
			ac = Cau6_2.tinhC(n[i]);
			assertEquals(ex[i], ac, 0);
		}
	}

}
