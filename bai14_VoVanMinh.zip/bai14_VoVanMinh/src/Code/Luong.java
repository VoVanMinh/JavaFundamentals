package Code;

public class Luong {

	public static double tinhLuong(double heSoLuong, double luongCB, double troCap, double thuong) {
		double luong = heSoLuong * luongCB + troCap + thuong;
		return luong;
	}
}
