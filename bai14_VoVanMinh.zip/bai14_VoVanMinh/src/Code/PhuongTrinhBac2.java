package Code;

public class PhuongTrinhBac2 {
	
	public static void main(String[] args) {
		System.out.println(giaiPTBac2(0, 1, 0));
	}
	
	public static String giaiPTBac2(float a, float b, float c) {
		String str = "";
		double x1;
		if (a == 0) {
			if (b == 0) {
				if (c == 0) {
					str = "Vo so nghiem";
				} else {
					str = "Vo nghiem";
				}
			} else {
				x1 = -(c/b);
				if(x1 == -0)
					x1 = 0;
				str = String.format("%.3f", x1);
			}
		} else {
			double delta = b * b - 4 * a * c;
			if (delta < 0) {
				str = "Vo nghiem";
			} else if (delta == 0) {
				x1 = (-b / (2 * a));
				if(x1 == -0)
					x1 = 0;
				str = String.format("%.3f", x1);
			} else {
				x1 = (-b + Math.sqrt(delta)) / (2 * a);
				str = String.format("%.3f", x1);
				x1 = (-b - Math.sqrt(delta)) / (2 * a);
				str += "; " + String.format("%.3f", x1);
			}
		}
		return str;
	}
}
