package Code;

public class TamGiac {
	public static boolean laTamGiac(int a, int b, int c) {
		boolean kiemTra = (a + b > c) && (a + c > b) && (b + c > a);
		return kiemTra;
	}
}
