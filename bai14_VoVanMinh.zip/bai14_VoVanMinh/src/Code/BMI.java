package Code;

public class BMI {

	public static float tinhbMI(float canNang, float chieuCao) {
		float bMI = canNang / (chieuCao * chieuCao);
		return bMI;
	}
}
