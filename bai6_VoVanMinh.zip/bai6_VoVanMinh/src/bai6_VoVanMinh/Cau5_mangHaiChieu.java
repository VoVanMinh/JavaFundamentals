package bai6_VoVanMinh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Cau5_mangHaiChieu {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Nhap vao so dong: ");
		int n = Integer.parseInt(input.readLine());

		System.out.println("Nhap vao so cot: ");
		int m = Integer.parseInt(input.readLine());

		int[][] arr = new int[n][m];
		System.out.println("Nhap vao cac phan tu trong mang: ");
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				System.out.println("\nNhap vao phan tu dong " + (i + 1) + " cot " + (j + 1));
				arr[i][j] = Integer.parseInt(input.readLine());
			}
		}

		System.out.println("Mang hai chieu da nhap la ");
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				System.out.print(arr[i][j] + "\t");
			}
			System.out.print("\n");
		}

		int dem = 0;
		float tongChan = 0;
		float tongLe = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (arr[i][j] % 2 == 0) {
					dem++;
					tongChan += arr[i][j];
				} else
					tongLe += arr[i][j];
			}
		}

		System.out.println("So phan tu chan trong mang la: " + dem);
		System.out.println("So phan tu le trong mang la: " + (n * m - dem));

		if (dem != 0) {
			tongChan /= dem;
			System.out.println("Trung binh cac phan tu chan la: " + tongChan);
		}
		if (dem != n * m) {
			tongLe /= (n * m - dem);
			System.out.println("Trung binh cac phan tu le la: " + tongLe);
		}

		int phanTu = arr[0][0];
		int vtN = 0;
		int vtM = 0;

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (phanTu < arr[i][j]) {
					phanTu = arr[i][j];
					vtN = i;
					vtM = j;
				}
			}
		}
		System.out.println("Phan tu lon nhat la : " + phanTu + " o dong " + vtN + " cot " + vtM);

		phanTu = arr[0][0];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (phanTu > arr[i][j]) {
					phanTu = arr[i][j];
					vtN = i;
					vtM = j;
				}
			}
		}
		System.out.println("Phan tu nho nhat la : " + phanTu + " o dong " + vtN + " cot " + vtM);

		dem = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (arr[i][j] < 0) {
					System.out.println("Mang co chua phan tu am.");
					dem = 1;
					break;
				}
			}
		}
		if (dem == 0)
			System.out.println("Mang khong co chua phan tu am.");

		// So co so lan xuat hien nhieu nhat
		dem = 0;
		int[] mang = new int[n * m];

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				mang[dem] = arr[i][j];
				dem++;
			}
		}

		dem = 1;
		int demMax = 1;
		phanTu = -1;
		for (int i = 0; i < mang.length - 1; i++) {
			dem = 1;
			for (int k = i + 1; k < mang.length; k++) {
				if (mang[k] == mang[i]) {
					dem++;
				}
			}
			if (dem > demMax) {
				demMax = dem;
				phanTu = mang[i];
			}
		}
		System.out.println("Phan tu xuat hien nhieu nhat la: " + phanTu + "\n\tVoi so lan xuat hien la : " + demMax);
		System.out.print("\tVi tri la: ");
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (arr[i][j] == phanTu)
					System.out.print(i + ":" + j + "\t");
			}
		}

	}

}
