package bai6_VoVanMinh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

public class Cau1 {

	public static void main(String[] args) throws NumberFormatException, IOException {

		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Nhap n: ");
		int n = Integer.parseInt(input.readLine());
		
		int[] a = new int[n];
		Random random = new Random();
		int sum = 0;
		for (int i = 0; i < n; i++) {
			a[i] = random.nextInt(10);
			sum += a[i];
		}
		int len = a.length;
		System.out.println("Mang ngau nhien: ");
		for (int i = 0; i < len; i++) {
			System.out.print(a[i] +" ");
		}
		System.out.println("\nTong la: " +sum);
	}

}
