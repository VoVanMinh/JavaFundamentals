package bai6_VoVanMinh;

public class moRong {

	public static void main(String[] args) {
		int[][] arr = { { 1, 2, 2 }, { 1, 2, 1 }, { 3, 4, 4 } };
		int n = 3, m = 3;
		
		System.out.println("Mang da nhap la ");
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				System.out.print(arr[i][j] + "\t");
			}
			System.out.print("\n");
		}

		/////////////////////////////Doi thanh mang mot chieu
		int dem = 0;
		int[] mang = new int[n * m];

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				mang[dem] = arr[i][j];
				dem++;
			}
		}
		//Tim gia tri voi so lan xuat hien lon nhat dau tien
		dem = 1;
		int demMax = 1;
		int phanTu = -1;
		int vt = -1;
		for (int i = 0; i < mang.length - 1; i++) {
			dem = 1;
			for (int k = i + 1; k < mang.length; k++) {
				if (mang[k] == mang[i]) {
					dem++;
				}
			}
			if (dem > demMax) {
				demMax = dem;
				phanTu = mang[i];
				vt = i;
			}
		}

		vt++;
		while (vt < mang.length - 1) {
			if (phanTu != -1) {
				System.out.println("\nPhan tu xuat hien nhieu nhat la: " + phanTu);
				System.out.println("\tVoi so lan xuat hien la : " + demMax);
				System.out.print("\tVi tri la: ");
				for (int i = 0; i < n; i++) {
					for (int j = 0; j < m; j++) {
					if (arr[i][j] == phanTu)
						System.out.print(i + ":" +j+ "\t");
					}
				}
			}

			dem = 1;
			phanTu = -1;
			if (mang[vt] != phanTu) {
				for (int k = vt + 1; k < mang.length; k++) {
					if (mang[k] == mang[vt]) {
						dem++;
					}
				}
				if (dem == demMax) {
					phanTu = mang[vt];
				}
			}
			vt++;
		}
		
		System.out.println("\n=======================================================");
		// So lan xuat hien cua tat ca cac phan tu trong mang
				dem = 1;
				phanTu = -1;
				for (int i = 0; i < mang.length - 1; i++) {
					dem = 1;
					for (int j = 0; j < i; j++) {
						if (mang[i] == mang[j]) {
							i++;
							dem = -1;
							break;
						}
					}
					if(dem == -1)
						continue;
					phanTu = mang[i];
					for (int k = i + 1; k < mang.length; k++) {
						if (mang[k] == mang[i]) {
							dem++;
						}
					}

					System.out.println("\nPhan tu " +phanTu +" co so lan cuat hien la: " +dem);
					System.out.print("\tVi tri la: ");
					for (int k = 0; k < n; k++) {
						for (int h = 0; h < m; h++) {
							if (arr[k][h] == phanTu)
								System.out.print(k + ":" + h + "\t");
						}
					}
					
				}


	}

}
