package bai6_VoVanMinh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Cau2_TimKiem {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Nhap vao n: ");
		int n = Integer.parseInt(input.readLine());

		int[] a = new int[n];
		System.out.println("Nhap cac phan tu cho mang: ");
		for (int i = 0; i < n; i++) {
			System.out.print("Nhap phan tu thu " + (i + 1) + "= ");
			a[i] = Integer.parseInt(input.readLine());
		}

		System.out.println("Nhap vao x: ");
		int x = Integer.parseInt(input.readLine());

		int len = a.length;
		System.out.print("Mang da nhap: ");
		for (int i = 0; i < len; i++) {
			System.out.print(a[i] + " ");
		}
		int count = 0;
		for (int i = 0; i < len; i++) {
			if (a[i] == x) {
				System.out.println("\n" + x + " xuat hien trong mang tai vi tri " + i);
				count = 1;
			}
		}
		if (count == 0) {
			System.out.println("\n" + x + " khong xuat hien trong mang");
		}
		count = 0;
		for (int i = 0; i < len; i++) {
			if (a[i] > x) {
				System.out.println("\n" + x + " khong lon hon cac phan tu trong mang");
				count = 1;
				break;
			}
		}
		if (count == 1) {
			System.out.println("\nCac phan tu lon hon " + x + " la: ");
			for (int i = 0; i < len; i++) {
				if (a[i] > x) {
					System.out.print(a[i] + " ");
				}
			}
		} else {
			System.out.println("\n" + x + " lon hon cac phan tu trong mang");
		}

	}
}
