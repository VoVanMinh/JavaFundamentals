package bai6_VoVanMinh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

public class Cau6_maTranVuong {

	static boolean soNguyenTo(int x) {
		if(x < 2)
			return false;
		int c = (int) Math.sqrt(x);
		int i = 2;
		while (i <= c) {
			if (x % i == 0) {
				return false;
			}
			i++;
		}
		return true;
	}

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Nhap vao m (dong va cot): ");
		int m = Integer.parseInt(input.readLine());

		int[][] arr = new int[m][m];
		Random random = new Random();
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < m; j++) {
				arr[i][j] = random.nextInt(20);
			}
		}

		System.out.println("Ma tran A da nhap la ");
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < m; j++) {
				System.out.print(arr[i][j] + "\t");
			}
			System.out.print("\n");
		}

		int tong = 0;
		int phanTu = arr[0][0];
		for (int i = 0; i < m; i++) {
			tong += arr[i][i];
			if (phanTu < arr[i][i]) {
				phanTu = arr[i][i];
			}
		}

		System.out.println("Tong gia tri tren duong cheo chinh la: " + tong);
		System.out.println("Phan tu lon nhat tren duong cheo chinh la: " + phanTu);

		phanTu = arr[0][0];
		for (int i = 0; i < m; i++) {
			if (phanTu > arr[i][i]) {
				phanTu = arr[i][i];
			}
		}
		System.out.println("Phan tu nho nhat tren duong cheo chinh la: " + phanTu);

		System.out.println("Cac so nguyen to trong ma tran la: ");
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < m; j++) {
				if (soNguyenTo(arr[i][j]))
					System.out.println("\t" +arr[i][j] + " o dong " +(i+1) +" cot " +(j+1));
			}
		}
		System.out.print("\n");

		System.out.println("Nhap vao n (dong va cot): ");
		int n = Integer.parseInt(input.readLine());
		int[][] arr2 = new int[n][n];
		System.out.println("Nhap vao cac phan tu trong mang: ");
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				System.out.println("\nNhap vao phan tu dong " + (i + 1) + " cot " + (j + 1));
				arr2[i][j] = Integer.parseInt(input.readLine());
			}
		}

		System.out.println("Ma tran da nhap la ");
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				System.out.print(arr2[i][j] + "\t");
			}
			System.out.print("\n");
		}

		int dem = 0;
		for (int i = 0; i < n; i++) {
			if(dem == 1)
				break;
			for (int j = 0; j < n; j++) {
				if (arr2[i][j] != arr2[j][i]) {
					System.out.println("Ma tran khong doi xung.");
					dem++;
					break;
				}
			}
		}
		if (dem == 0)
			System.out.println("Ma tran nay doi xung.");

		System.out.println("Nhap vao c (dong va cot): ");
		int c = Integer.parseInt(input.readLine());
		int[][] arr3 = new int[c][c];
		for (int i = 0; i < c; i++) {
			for (int j = 0; j < c; j++) {
				arr3[i][j] = arr[i][j] + arr2[i][j];
			}
		}
		System.out.println("Ma tran da nhap la ");
		for (int i = 0; i < c; i++) {
			for (int j = 0; j < c; j++) {
				System.out.print(arr3[i][j] + "\t");
			}
			System.out.print("\n");
		}

		System.out.println("Nhap vao cot k: ");
		int dem1 = 0;
		int k = Integer.parseInt(input.readLine());
		if (k > m)
			System.out.println(k + " qua lon!");
		else {
			for (int i = 0; i < c - 1; i++) {
				if (arr3[i + 1][k-1] < arr3[i][k-1]) {
					System.out.println("Cot " +k +" nay khong tang dan");
					dem1 = 1;
					break;
				}
			}
			if(dem1 == 0)
				System.out.println("Cot " +k +" nay tang dan");
		}
		
	}

}
