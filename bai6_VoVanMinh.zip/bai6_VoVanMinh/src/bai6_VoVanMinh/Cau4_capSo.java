package bai6_VoVanMinh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Cau4_capSo {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

		int[] a = new int[5];
		System.out.println("Nhap cac phan tu cho mang: ");
		for (int i = 0; i < 5; i++) {
			System.out.print("Nhap phan tu thu " + (i + 1) + "= ");
			a[i] = Integer.parseInt(input.readLine());
		}

		System.out.print("Mang da nhap: ");
		for (int i = 0; i < a.length; i++) {
			System.out.print(a[i] + " ");
		}

		System.out.print("\nCac cap so chia het cho nhau la: ");
		for (int i = 0; i < a.length - 1; i++) {
			for (int j = i + 1; j < a.length; j++) {
				if ((a[i] % a[j] == 0) || (a[j] % a[i] == 0)) {
					System.out.print(a[i] + " & " + a[j] + ", ");
				}
			}
		}

		System.out.print("\nCac cap so gap doi nhau la: ");
		for (int i = 0; i < a.length - 1; i++) {
			for (int j = i + 1; j < a.length; j++) {
				if ((a[i] * 2 == a[j]) || (a[j] * 2 == a[i])) {
					System.out.print(a[i] + " & " + a[j] + ", ");
				}
			}
		}

		System.out.print("\nCac cap so cong lai bang 8 la: ");
		for (int i = 0; i < a.length - 1; i++) {
			for (int j = i + 1; j < a.length; j++) {
				if (a[i] + a[j] == 8) {
					System.out.print(a[i] + " &" + a[j] + ", ");
				}
			}
		}

	}

}
