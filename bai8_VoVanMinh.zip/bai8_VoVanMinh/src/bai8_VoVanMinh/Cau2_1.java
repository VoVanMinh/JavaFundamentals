package bai8_VoVanMinh;

public class Cau2_1 {
	public static void main(String[] args) {

		int x = 5, y = 0;

		if (!Double.isNaN(tinhThuong(x, y))) {
			System.out.println(tinhThuong(x, y));
		}

		tinhTich(x, y);

		tinhTong(x, y);

		tinhHieu(x, y);

	}

	private static double tinhThuong(int x, int y) {

		double tinhToan = 0;
		try {
			if (y == 0)
				throw new ArithmeticException("Loi chia cho 0");

			tinhToan = x / y;

		} catch (Exception e) {
			System.out.println(e.getMessage());
			tinhToan = Double.NaN;
			// tinhToan = null;
		}
		return tinhToan;

	}

	private static void tinhHieu(int x, int y) {
		// TODO Auto-generated method stub
		System.out.println("Hieu la: " + (x - y));
	}

	private static void tinhTong(int x, int y) {
		System.out.println("Tong la: " + (x + y));

	}

	private static void tinhTich(int x, int y) {
		System.out.println("Tich la: " + x * y);

	}

}
