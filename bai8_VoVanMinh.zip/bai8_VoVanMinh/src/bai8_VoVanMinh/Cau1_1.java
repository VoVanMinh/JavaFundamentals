package bai8_VoVanMinh;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Cau1_1 {
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
		System.out.println("Nhap vao n: ");
		try {
			int n = input.nextInt();

			System.out.println("Ket qua A = " + tinhA(n));
			System.out.println("Ket qua B = " + tinhB(n));
			System.out.println("Ket qua C = " + tinhC(n));
			System.out.println("Ket qua D = " + tinhD(n));

		} catch (InputMismatchException e) {
			System.out.println("Vui long nhap so.");
		}
	}

	private static int tinhA(int n) {
		if(n < 2)
			return 0;
		int A = 0;
		for (int i = 2; i <= n; i++) {
			if (i % 2 == 0)
				A += i;
		}
		return A;
	}

	private static int tinhB(int n) {
		if(n < 1)
			return 0;
		int B = 0;
		for (int i = 1; i <= n; i++) {
			if (i % 2 == 1)
				B += i;
		}
		return B;
	}

	private static int tinhC(int n) {
		if(n < 1)
			return 0;
		int C = 1;
		for (int i = 1; i <= n; i++) {
			C *= i;
		}
		return C;
	}

	private static int tinhD(int n) {
		if(n < 3)
			return 0;
		int D = 1;
		for (int i = 3; i <= n; i++) {
			if (i % 3 == 0)
				D *= i;
		}
		return D;
	}

}
