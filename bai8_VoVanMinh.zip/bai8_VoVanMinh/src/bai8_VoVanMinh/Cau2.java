package bai8_VoVanMinh;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Cau2 {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);

		try {

			System.out.println("Nhap vao x: ");
			int x = input.nextInt();
			System.out.println("Nhap vao y: ");
			int y = input.nextInt();

			tinhGTBT(x, y);

			tinhTich(x, y);

		} catch (InputMismatchException e) {
			System.out.println("Vui long nhap so.");
		}
		// catch (ArithmeticException e) {
		// System.out.println(e.getMessage());
		// }
	}

	private static void tinhTich(int x, int y) {
		System.out.println("Tich la: " + x * y);

	}

	private static void tinhGTBT(int x, int y) {

		double tinhToan = 0;
		boolean temp = true;
		try {
			double tuSo = 5 * x - y;
			double mauSo = 2 * x + 7 * y;
			if (mauSo == 0) {
				throw new ArithmeticException("Loi chia cho 0");
			}
			tinhToan = tuSo / mauSo;
			if (tinhToan < 0) {
				throw new ArithmeticException("Loi can bac 2 cho so am");
			}
		} catch (ArithmeticException e) {
			System.out.println(e.getMessage());
			temp = false;
		}
		if (temp == true)
			System.out.println("Ket qua la: " +tinhToan);
	}

}
