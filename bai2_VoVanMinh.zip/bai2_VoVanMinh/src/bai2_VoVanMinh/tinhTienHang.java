package bai2_VoVanMinh;

import java.util.Scanner;

public class tinhTienHang {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Nhap so luong: ");
		int soLuong = input.nextInt();
		System.out.print("Nhap don gia: ");
		float donGia = input.nextFloat();
		double thanhTien = soLuong*donGia;
		System.out.println("Thanh tien = " +String.format("%.0f", thanhTien));
	}

}
