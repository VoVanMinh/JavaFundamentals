package bai2_VoVanMinh;

import java.util.Scanner;

public class tinhTienHang {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Nhập số lượng: ");
		int soLuong = input.nextInt();
		System.out.print("Nhap đơn giá: ");
		float donGia = input.nextFloat();
		double thanhTien = soLuong*donGia;
		System.out.println("Thành tiền = " +String.format("%.0f", thanhTien));
	}

}
