package bai2_VoVanMinh;

import java.util.Scanner;

public class hinhTron {

	public static void main(String[] args) {
		final double PI = 3.14;
		Scanner input = new Scanner(System.in);
		System.out.print("Nhap ban kinh: ");
		float banKinh = input.nextFloat();
		System.out.println("Chu vi: " +(PI*2*banKinh));
		System.out.println("Dien tich: " +(PI*banKinh*banKinh));
	}

}
