package bai2_VoVanMinh;

import java.util.Scanner;

public class tinhThucLinh {

	public static void main(String[] args) {
Scanner input = new Scanner(System.in);
		
		System.out.print("So san pham: ");
		int sp = input.nextInt();
		
		System.out.print("Tien cong: ");
		float tc = input.nextFloat();
		
		System.out.print("Tien thuong: ");
		int tt = input.nextInt();
		
		System.out.print("So con: ");
		float sc = input.nextFloat();
		
		double tl  = sp*tc + tt +sc*200000;
		
		System.out.println("Tien luong: " +sp*tc);
		System.out.println("Phu cap: " +sc*200000);
		System.out.println("Thuc linh : " +tl);
	}

}
