package bai2_VoVanMinh;

import java.util.Scanner;

public class doiTien {

	public static void main(String[] args) {
		
Scanner input = new Scanner(System.in);
		
		System.out.print("Ten ngoai te: ");
		String ten = input.nextLine();
		
		System.out.print("Ty gia: ");
		float tg = input.nextFloat();
		
		System.out.print("So ngoai te: ");
		int sl = input.nextInt();
		
		double tt  = tg*sl;
		
		System.out.println("Ban dang doi tien tu " +sl +" " +ten +"sang VND la:" +tt);
	
	}

}
