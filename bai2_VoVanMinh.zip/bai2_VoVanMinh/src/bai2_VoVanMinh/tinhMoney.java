package bai2_VoVanMinh;

import java.util.Scanner;

public class tinhMoney {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
		
		System.out.print("Lai suat mot nam: ");
		float ls = input.nextFloat();
		
		System.out.print("soTienGui: ");
		float stg = input.nextFloat();
		
		System.out.print("So thang: ");
		int st = input.nextInt();
		
		double tienLai  = stg*st*ls/1200;
		double tongTien  = stg + tienLai;
		
		System.out.println("Tien lai: " +tienLai +"\nTong tien:" +tongTien);
	}

}
