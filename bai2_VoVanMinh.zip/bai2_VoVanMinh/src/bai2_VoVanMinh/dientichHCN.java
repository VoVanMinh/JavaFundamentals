package bai2_VoVanMinh;

public class dientichHCN {

	public static void main(String[] args) {
		

	}

}
