package bai2_VoVanMinh;

import java.util.Scanner;

public class dientichHCN {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
		
		System.out.print("Chu vi HCN la: ");
		float cv = input.nextFloat();
		
		System.out.println("Dien tich HCN la: " +cv*cv*1.5/25);

	}

}
