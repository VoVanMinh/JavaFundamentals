package bai2_VoVanMinh;

import java.util.Scanner;

public class tinhBanKinh {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Nhap dien tich: ");
		float dt = input.nextFloat();
		System.out.println("Ban kinh: " +(Math.sqrt(dt/3.14)));
	}

}
