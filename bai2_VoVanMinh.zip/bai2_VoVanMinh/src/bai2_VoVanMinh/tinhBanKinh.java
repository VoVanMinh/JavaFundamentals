package bai2_VoVanMinh;

import java.util.Scanner;

public class tinhBanKinh {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Nhập chu vi: ");
		float chuvi = input.nextFloat();
		System.out.println("Diện tích: " +(chuvi*chuvi*1.5/25));

	}

}
