package TestDay1;

import static org.junit.Assert.*;

import org.junit.Test;

import Day1.Cau3;

public class TestCau3 {

	@Test
	public void test() {
		int[] giaVe = { 129000, 249000, 146000, 99000, 155000 };
		float[] ex = { 0, 560250, 657000, 668250, 1395000};

		float ac;

		for (int i = 0; i < 5; i++) {
			ac = Cau3.tinhTienVe(giaVe[i], i, i, i);
			assertEquals(ex[i], ac, 0);
		}
	}

}
