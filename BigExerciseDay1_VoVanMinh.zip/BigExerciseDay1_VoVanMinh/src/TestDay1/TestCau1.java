package TestDay1;

import static org.junit.Assert.*;
import Day1.*;

import org.junit.Test;

public class TestCau1 {

	@Test
	public void test() {
		String[] tenGoi = { "M0", "M10", "M25", "M50", "M120", "MAX", "MAX100", "MAX200", "MAXS" };
		float dungLuong = 200000;
		float[] ex = { 300000, 84400, 48200, 50000, 120000, 70000, 100000, 200000, 50000 };

		float ac;

		for (int i = 0; i < 9; i++) {
			ac = Cau1.cuocPhaiTra(tenGoi[i], dungLuong);
			assertEquals(ex[i], ac, 0);
		}
	}

}
