package TestDay1;

import static org.junit.Assert.*;

import org.junit.Test;
import Day1.*;
public class TestCau7 {

	@Test
	public void test() {
		int[] tp = { 1, 5, 15, 55, 75 };
		String[] ex = { "1", "5", "F", "37", "4B"};

		String ac;

		for (int i = 0; i < 5; i++) {
			ac = Cau7.doi10den16(tp[i]);
			assertEquals(ex[i], ac);
		}
	}

}
