package TestDay1;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TestCau1.class, TestCau3.class, TestCau7.class })
public class TestSuite {

}
