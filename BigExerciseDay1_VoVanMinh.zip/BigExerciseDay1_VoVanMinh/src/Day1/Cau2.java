package Day1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Cau2 {

	public static void main(String[] args) throws IOException {

		BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
		try {
			int n;
			do {
				System.out.println("Nhap vao n (dong va cot): ");
				n = Integer.parseInt(nhap.readLine());
			} while (n < 1);

			int[][] arr = new int[n][n];

			nhapMang(arr);
			xuatMang(arr);

			phanTuLonNhoNhatDong(arr);

			System.out.println("Nhap vao x: ");
			int x = Integer.parseInt(nhap.readLine());

			datxTrenDCC(arr, x);
			xuatMang(arr);

			if (ptAmLonNhat(arr) == Integer.MIN_VALUE)
				System.out.println("Mang khong co phan tu am.");
			else
				System.out.println("Phan tu am lon nhat la: " + ptAmLonNhat(arr));

			if (ptDuongNhoNhat(arr) == Integer.MAX_VALUE)
				System.out.println("Mang khong co phan tu duong.");
			else
				System.out.println("Phan tu duong nho nhat la: " + ptDuongNhoNhat(arr));

			System.out
					.println("So phan tu duong nam o tam giac phia tren duong cheo chinh: " + demDuongTamGiacTren(arr));
			System.out.println("So phan tu am chia het cho 2 va 3 la: " + demChiaHet2va3(arr));

		} catch (NumberFormatException e) {
			System.out.println("Vui long nhap vao dung so");
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	private static int demChiaHet2va3(int[][] arr) {
		int dem = 0;
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr.length; j++) {
				if (arr[i][j] < 0) {
					if ((arr[i][j] % 6 == 0))
						dem++;
				}
			}
		}
		return dem;
	}

	private static int demDuongTamGiacTren(int[][] arr) {
		int dem = 0;
		for (int i = 0; i < arr.length; i++) {
			for (int j = arr.length - 1; j >= i; j--) {
				if (arr[i][j] > 0)
					dem++;
			}
		}
		return dem;
	}

	private static int ptDuongNhoNhat(int[][] arr) {
		int min = Integer.MAX_VALUE;
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr.length; j++) {
				if (arr[i][j] > 0) {
					if (arr[i][j] < min)
						min = arr[i][j];
				}
			}
		}
		return min;
	}

	private static int ptAmLonNhat(int[][] arr) {
		int max = Integer.MIN_VALUE;
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr.length; j++) {
				if (arr[i][j] < 0) {
					if (arr[i][j] > max)
						max = arr[i][j];
				}
			}
		}
		return max;
	}

	private static void datxTrenDCC(int[][] arr, int x) {
		for (int i = 0; i < arr.length; i++) {
			arr[i][i] = x;
			arr[i][arr.length - 1 - i] = x;
		}
	}

	private static void phanTuLonNhoNhatDong(int[][] arr) {
		int max;
		int min;
		for (int i = 0; i < arr.length; i++) {
			max = arr[i][0];
			min = arr[i][0];
			for (int j = 0; j < arr.length; j++) {
				if (arr[i][j] > max)
					max = arr[i][j];
				if (arr[i][j] < min)
					min = arr[i][j];
			}
			System.out.println("Phan tu lon nhat dong " + (i + 1) + " la : " + max);
			System.out.println("Phan tu nho nhat dong " + (i + 1) + " la : " + min);
			System.out.println("---------------------------------");
		}

	}

	private static void xuatMang(int[][] arr) {
		System.out.println("Ma tran da nhap la ");
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[0].length; j++) {
				System.out.print(arr[i][j] + "\t");
			}
			System.out.print("\n");
		}

	}

	private static void nhapMang(int[][] arr) throws NumberFormatException, IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Nhap vao cac phan tu trong mang: ");
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[0].length; j++) {
				System.out.println("\nNhap vao phan tu dong " + (i + 1) + " cot " + (j + 1));
				arr[i][j] = Integer.parseInt(input.readLine());
			}
		}

	}

}
