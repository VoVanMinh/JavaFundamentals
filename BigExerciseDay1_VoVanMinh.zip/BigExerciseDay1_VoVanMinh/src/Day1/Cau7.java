package Day1;

import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Cau7 {

	public static void main(String[] args) {

		System.out.println("1. Doi tu thap phan sang thap luc phan.");
		System.out.println("2. Doi tu thap luc phan sang thap phan.");
		System.out.println("Nhap vao lua chon (1 hoac 2): ");
		@SuppressWarnings("resource")
		Scanner nhap = new Scanner(System.in);
		String luaChon = nhap.nextLine();
		switch (luaChon) {
		case "1":
			System.out.println("Nhap vao so thap phan: ");
			try {

				int tp = nhap.nextInt();
				System.out.println("So thap luc phan la: " + doi10den16(tp));

			} catch (InputMismatchException e) {
				System.out.println("Ban da nhap sai!");
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}

			break;

		case "2":
			System.out.println("Nhap vao so thap luc phan: ");
			try {

				String tlp = nhap.nextLine();
				String re = "^([0-9a-fA-F]+)$";

				Pattern p = Pattern.compile(re);
				Matcher m = p.matcher(tlp);

				if (!m.matches())
					throw new InputMismatchException();
				else
					System.out.println("So thap phan la: " + doi16den10(tlp));

			} catch (InputMismatchException e) {
				System.out.println("Ban da nhap sai!");
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			break;

		default:
			System.out.println("Ban da nhap sai!");
			break;
		}

	}

	private static int chuyenLai(Character c) {

		switch (c) {
		case 'A':
		case 'a':
			return 10;
		case 'B':
		case 'b':
			return 11;
		case 'C':
		case 'c':
			return 12;
		case 'D':
		case 'd':
			return 13;
		case 'E':
		case 'e':
			return 14;
		case 'F':
		case 'f':
			return 15;
		default:
			return Integer.parseInt(c.toString());
		}
	}

	private static double doi16den10(String tlp) {
		double tong = 0;
		int j = 0;
		for (int i = tlp.length() - 1; i >= 0; i--) {
			tong += chuyenLai(tlp.charAt(i)) * Math.pow(16, j);
			j++;
		}
		return tong;
	}

	private static String layPhanDu(int n) {

		int temp = n % 16;
		switch (temp) {

		case 10:
			return "A";

		case 11:
			return "B";

		case 12:
			return "C";

		case 13:
			return "D";

		case 14:
			return "E";

		case 15:
			return "F";

		default:
			return String.valueOf(temp);
		}
	}

	public static String doi10den16(int tp) {
		StringBuilder sb = new StringBuilder("");
		while (tp > 0) {
			sb.append(layPhanDu(tp));
			tp /= 16;
		}
		sb.reverse();

		return sb.toString();
	}

}
