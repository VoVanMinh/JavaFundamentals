package Day1;

import java.util.Random;
import java.util.Scanner;

/*
Code cua Ha Tan Dien
*/
public class Cau9 {

	static Scanner input = new Scanner(System.in);
    static Random random = new Random();
    static int[] MANGSO = {1, 3, 4, 2, 5, 6, 9, 8, 7};

    public static void main(String[] args) {
        int soNgauNhien = random.nextInt(9);
        int[] mangSo = mangNgauNhien(MANGSO, soNgauNhien);
        int[][] SoDoKu = taoSoDoKu(mangSo);
        xuatSoDoKu(SoDoKu);
    }

    public static int[] mangNgauNhien(int[] mangso, int n) {
        int[] mangtam = mangso.clone();
        for (int j = 0; j < n; j++) {
            for (int i = 0; i < 8; i++) {
                int tam = mangtam[i];
                mangtam[i] = mangtam[i + 1];
                mangtam[i + 1] = tam;
            }
        }
        return mangtam;
    }

    public static int[][] taoSoDoKu(int[] mang) {
        int[][] tam = new int[9][9];
        for (int i = 0; i < 9; i++) {
            int[] mangtam;
            if (i < 3) {
                mangtam = mangNgauNhien(mang, 3 * (i % 3));
            } else if (i < 6) {
                mangtam = mangNgauNhien(mang, 3 * (i % 3) + 1);
            } else {
                mangtam = mangNgauNhien(mang, 3 * (i % 3) + 2);
            }
            for (int j = 0; j < 9; j++) {
                tam[i][j] = mangtam[j];
            }

        }
        return tam;
    }

    public static void xuatSoDoKu(int[][] soDoKu) {
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                System.out.print(soDoKu[i][j] + " ");
                if (j + 1 == 3 || (j + 1) == 6) {
                    System.out.print(" | ");
                }
            }
            if (i + 1 == 3 || (i + 1) == 6) {
                System.out.println();
                for (int k = 0; k < 25; k++) {
                    System.out.print("-");
                }
            }
            System.out.println();
        }
    }

}
