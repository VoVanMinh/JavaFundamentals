package Day1;

import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class Cau8 {

	public static void main(String[] args) {

		@SuppressWarnings("resource")
		Scanner nhap = new Scanner(System.in);

		try {
			int n;
			do {
				System.out.println("Nhap vao so phan tu cua mang: ");
				n = nhap.nextInt();
			} while (n < 1);
			
			int[] a = new int[n];
			
			mangNgauNhien(a);
			
			String[] s = chuyenVaoMang(a);
			thongKe(s);
			xuatMang(a);
			
		} catch (InputMismatchException e) {
			System.out.println("Vui long nhap vao so!");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}
	
	private static String[] chuyenVaoMang(int[] a){
		String[] s = new String [10];
		for (int i = 0; i < s.length; i++) {
			s[i] = "";
		}
		for (int i = 0; i < a.length; i++) {			
			if(a[i] < 10)
				s[0] += "*";
			else if(a[i] < 20)
				s[1] += "*";
			else if(a[i] < 30)
				s[2] += "*";
			else if(a[i] < 40)
				s[3] += "*";
			else if(a[i] < 50)
				s[4] += "*";
			else if(a[i] < 60)
				s[5] += "*";
			else if(a[i] < 70)
				s[6] += "*";
			else if(a[i] < 80)
				s[7] += "*";
			else if(a[i] < 90)
				s[8] += "*";
			else
				s[9] += "*";
		}
		return s;
			
	}
	
	private static void thongKe(String[] s) {
		int b = 0;
	
		for (int i = 0; i < s.length; i++) {
			if(b < 90)
				System.out.print(b +" -" +(b + 9) + ": ");
			else 
				System.out.print(b +" -" +(b + 10) + ": ");
			
			System.out.println(s[i]);
			b += 10;
		}		
	}

	private static int[] mangNgauNhien(int[] a) {
		Random random = new Random();
		for (int i = 0; i < a.length; i++) {
			a[i] = random.nextInt(100);
		}
		return a;
	}

	private static void xuatMang(int[] a) {
		System.out.print("Mang ngau nhien la: ");
		for (int i = 0; i < a.length; i++) {
			System.out.print(a[i] + " ");
		}

	}
}
