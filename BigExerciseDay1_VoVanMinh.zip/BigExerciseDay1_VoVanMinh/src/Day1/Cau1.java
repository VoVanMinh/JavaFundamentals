package Day1;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Cau1 {

	final static int M10 = 50 * 1024;
	final static int M25 = 150 * 1024;
	final static int M50 = 500 * 1024;
	final static float M120 = (float) 1.5 * 1024 * 1024;

	final static int MM10 = 10000;
	final static int MM25 = 25000;
	final static int MM50 = 50000;
	final static int MM120 = 120000;
	final static int MMAX = 70000;
	final static int MMAX100 = 100000;
	final static int MMAX200 = 200000;
	final static int MMAXS = 50000;

	final static float B1 = (float) 1.5;
	final static float B2 = (float) 0.5;

	public static void main(String[] args) {

		@SuppressWarnings("resource")
		Scanner nhap = new Scanner(System.in);
		String tenGoi = null;
		float dungLuong = 0;

		try {
			System.out.print("Nhap vao ten goi cuoc: ");
			tenGoi = nhap.nextLine();

			System.out.println("Nhap vao dung luong da su dung (KB): ");
			dungLuong = nhap.nextInt();

			System.out.println("Tong so tien cuoc phai tra la: ");
			System.out.println(cuocPhaiTra(tenGoi, dungLuong));

		} catch (InputMismatchException e) {
			System.out.println("Vui long nhap vao so!");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public static float cuocPhaiTra(String tenGoi, float dungLuong) {

		if (dungLuong <= 0)
			return 0;
		float tienCuoc = 0;
		if (tenGoi.equalsIgnoreCase("M0")) {

			tienCuoc = dungLuong * B1;

		} else if (tenGoi.equalsIgnoreCase("M10")) {

			if (dungLuong <= M10)
				tienCuoc = MM10;
			else
				tienCuoc = MM10 + (dungLuong - M10) * B2;

		} else if (tenGoi.equalsIgnoreCase("M25")) {

			if (dungLuong <= M25)
				tienCuoc = MM25;
			else
				tienCuoc = MM25 + (dungLuong - M25) * B2;
		} else if (tenGoi.equalsIgnoreCase("M50")) {

			if (dungLuong <= M50)
				tienCuoc = MM50;
			else
				tienCuoc = MM50 + (dungLuong - M50) * B2;

		} else if (tenGoi.equalsIgnoreCase("M120")) {

			if (dungLuong <= M120)
				tienCuoc = MM120;
			else
				tienCuoc = MM120 + (dungLuong - M120) * B2;

		} else if (tenGoi.equalsIgnoreCase("MAX")) {
			tienCuoc = MMAX;
		} else if (tenGoi.equalsIgnoreCase("MAX100")) {
			tienCuoc = MMAX100;
		} else if (tenGoi.equalsIgnoreCase("MAX200")) {
			tienCuoc = MMAX200;
		} else if (tenGoi.equalsIgnoreCase("MAXS")) {
			tienCuoc = MMAXS;
		} else {
			tienCuoc = dungLuong * B1;
		}
		return tienCuoc;
	}

}
