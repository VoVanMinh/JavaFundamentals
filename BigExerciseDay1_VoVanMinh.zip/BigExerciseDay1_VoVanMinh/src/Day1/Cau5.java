package Day1;

import java.util.Random;

public class Cau5 {

	public static void main(String[] args) {

		int n = 5;
		int[] a = new int[n];
		mangNgauNhien(a);
		xuatMang(a);

		String[][] arr = new String[n][n];
		ganGiaTri(arr, a);
		xuatMaTran(arr);

	}

	private static void xuLyNull(String[][] maTran) {
		for (int i = 0; i < maTran.length; i++) {
			for (int j = 0; j < maTran[0].length; j++) {
				if (maTran[i][j] == null)
					maTran[i][j] = "*";
			}
		}

	}

	private static void xuatMaTran(String[][] arr) {

		System.out.println("\nMang hai chieu da nhap la ");
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[0].length; j++) {
				System.out.print(arr[i][j] + "\t");
			}
			System.out.print("\n");
		}

	}

	private static void ganGiaTri(String[][] arr, int[] a) {
		for (int i = 0; i < arr.length; i++) {
			arr[i][a[i]] = "Q";
		}
		xuLyNull(arr);
	}

	private static int[] mangNgauNhien(int[] a) {
		Random random = new Random();
		for (int i = 0; i < a.length; i++) {
			a[i] = random.nextInt((a.length - 1));
		}
		return a;
	}

	private static void xuatMang(int[] a) {
		System.out.print("Mang da nhap: ");
		for (int i = 0; i < a.length; i++) {
			System.out.print(a[i] + " ");
		}

	}

}
