package Day1;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Cau3 {

	final static int B1 = 129000;
	final static int B2 = 128000;
	final static int B3 = 249000;
	final static int B4 = 218000;
	final static int B5 = 202000;
	final static int B6 = 172000;
	final static int B7 = 214000;
	final static int B8 = 189000;
	final static int B9 = 163000;
	final static int B10 = 193000;
	final static int B11 = 168000;
	final static int B12 = 146000;
	final static int B13 = 79000;
	final static int B14 = 99000;
	final static int B15 = 116000;
	final static int B16 = 129000;
	final static int B17 = 155000;
	final static int B18 = 171000;

	public static void main(String[] args) {
		try {
			System.out.println("Nhap loai ghe: ");
			@SuppressWarnings("resource")
			Scanner nhap = new Scanner(System.in);
			String loaiGhe = nhap.nextLine();

			System.out.println("Nhap tong so ve muon mua:");
			int soVeNguoiLon;
			int soVeTreEm;
			int soVeNguoiGia;

			do {
				System.out.println("So ve cho nguoi lon >=0: ");
				soVeNguoiLon = nhap.nextInt();
			} while (soVeNguoiLon < 0);

			do {
				System.out.println("So ve cho tre em >=0: ");
				soVeTreEm = nhap.nextInt();
			} while (soVeTreEm < 0);

			do {
				System.out.println("So ve cho nguoi gia >=0: ");
				soVeNguoiGia = nhap.nextInt();
			} while (soVeNguoiGia < 0);

			int giaVe = tinhGiaVe(loaiGhe);
			
			System.out.println("Tong so ve la: " + (soVeNguoiLon + soVeTreEm + soVeNguoiGia));
			
			System.out.print("So ve nguoi lon la: " + soVeNguoiLon);
			System.out.println("\tThanh tien: " + soVeNguoiLon*giaVe);

			System.out.print("So ve tre em la: " + soVeTreEm);
			System.out.println("\tThanh tien: " + soVeTreEm*giaVe*0.5);

			System.out.print("So ve nguoi gia la: " + soVeNguoiGia);
			System.out.println("\tThanh tien: " + soVeNguoiGia*giaVe*0.75);
			
			System.out.println("Tong so tien ve la: " +tinhTienVe(giaVe, soVeNguoiLon, soVeTreEm, soVeNguoiGia));

		} catch (InputMismatchException e) {
			System.out.println("vui long nhap vao so!");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	private static int tinhGiaVe(String loaiGhe) {
		int giaVe = 0;
		if (loaiGhe.equalsIgnoreCase("A2T")) {
			giaVe = B1;
		} else if (loaiGhe.equalsIgnoreCase("A2TL")) {
			giaVe = B2;
		}else if (loaiGhe.equalsIgnoreCase("AnLT1")) {
			giaVe = B3;
		}else if (loaiGhe.equalsIgnoreCase("AnLT2")) {
			giaVe = B4;
		}else if (loaiGhe.equalsIgnoreCase("AnT1")) {
			giaVe = B5;
		}else if (loaiGhe.equalsIgnoreCase("AnT2")) {
			giaVe = B6;
		}else if (loaiGhe.equalsIgnoreCase("BnLT1")) {
			giaVe = B7;
		}else if (loaiGhe.equalsIgnoreCase("BnLT2")) {
			giaVe = B8;
		}else if (loaiGhe.equalsIgnoreCase("BnLT3")) {
			giaVe = B9;
		}else if (loaiGhe.equalsIgnoreCase("BnT1")) {
			giaVe = B10;
		}else if (loaiGhe.equalsIgnoreCase("BnT2")) {
			giaVe = B11;
		}else if (loaiGhe.equalsIgnoreCase("BnT3")) {
			giaVe = B12;
		}else if (loaiGhe.equalsIgnoreCase("GP")) {
			giaVe = B13;
		}else if (loaiGhe.equalsIgnoreCase("NC")) {
			giaVe = B14;
		}else if (loaiGhe.equalsIgnoreCase("NCL")) {
			giaVe = B15;
		}else if (loaiGhe.equalsIgnoreCase("NM")) {
			giaVe = B16;
		}else if (loaiGhe.equalsIgnoreCase("NML")) {
			giaVe = B17;
		}else if (loaiGhe.equalsIgnoreCase("NML4V")) {
			giaVe = B18;
		}
		else 
			giaVe = 0;
		return giaVe;
	}

	public static float tinhTienVe(int giaVe, int soVeNguoiLon, int soVeTreEm, int soVeNguoiGia) {
		if(soVeNguoiLon < 0 || soVeNguoiGia < 0 || soVeTreEm < 0)
			return 0;
		float tongTien = 0;
		tongTien = (float) (soVeNguoiLon*giaVe + (float)soVeTreEm*giaVe*0.5 + (float)soVeNguoiGia*giaVe*0.75);
		return tongTien;

	}

}
