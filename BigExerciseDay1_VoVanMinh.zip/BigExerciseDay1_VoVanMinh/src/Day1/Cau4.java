package Day1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class Cau4 {

	public static void main(String[] args) {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		try {
			int n;
			do {

				System.out.println("Nhap vao so nguyen duong: ");
				n = Integer.parseInt(input.readLine());
			} while (n < 1);

			String[] mangChuoi = new String[n];
			nhapMang(mangChuoi);
			xuatMang(mangChuoi);

			chuoiDaiNhat(mangChuoi);

			System.out.print("\nNhap vao mot chuoi: ");
			String chuoi = input.readLine();

			int vt = kiemTraChuoi(mangChuoi, chuoi);
			if (vt == -1)
				System.out.println(chuoi + "khong xuat hien trong mang.");
			else
				System.out.println(chuoi + "xuat hien o vi tri: " + (vt + 1));

			String[] chuoiMoi = saoChepMangChuoi(mangChuoi);

			sapXepMangMoi(chuoiMoi);
			xuatMangMoi(chuoiMoi);

		} catch (NumberFormatException e) {
			System.out.println("Vui long nhap vao so.");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	private static void xuatMangMoi(String[] chuoiMoi) {
		System.out.println("\nMang moi la: ");
		for (String string : chuoiMoi) {
			System.out.print(string + "\t");
		}
	}

	private static void chuoiDaiNhat(String[] mangChuoi) {
		int max = mangChuoi[0].length();
		for (int i = 0; i < mangChuoi.length; i++) {
			if (mangChuoi[i].length() > max) {
				max = mangChuoi[i].length();
			}
		}
		System.out.println("Phan tu co do dai lon nhat la " + max + " la: ");
		for (int i = 0; i < mangChuoi.length; i++) {
			if (mangChuoi[i].length() == max) {
				System.out.print(mangChuoi[i] + " o vi tri " + (i + 1) + "\t");
			}
		}
	}

	private static int kiemTraChuoi(String[] mangChuoi, String chuoi) {
		for (int i = 0; i < mangChuoi.length; i++) {
			if (chuoi.equalsIgnoreCase(mangChuoi[i])) {
				return (i);
			}
		}
		return -1;
	}

	private static void xuatMang(String[] mangChuoi) {
		System.out.println("\nMang da nhap la: ");
		for (String string : mangChuoi) {
			System.out.println(string);
			System.out.println("Do dai la: " + string.length());
		}
	}

	private static void nhapMang(String[] mangChuoi) throws IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		for (int i = 0; i < mangChuoi.length; i++) {
			System.out.print("\nNhap vao phan tu thu " + (i + 1) + ": ");
			mangChuoi[i] = input.readLine();
		}

	}

	private static void sapXepMangMoi(String[] chuoiMoi) {
		Arrays.parallelSort(chuoiMoi);
	}

	private static String[] saoChepMangChuoi(String[] mangChuoi) {

		String[] chuoiMoi = mangChuoi.clone();
		return chuoiMoi;
	}

}
