package bai13_VoVanMinh;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Cau1 {

	public static void main(String[] args) {
		
		SimpleDateFormat sdf = new SimpleDateFormat("E dd/MM/yyyy HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		
		System.out.println("Hom nay la: " +sdf.format(cal.getTime()));
		System.out.println("Hom nay la thu " +(cal.get(Calendar.DAY_OF_WEEK)));
		System.out.println("La tuan thu " +sdf.format(cal.get(Calendar.WEEK_OF_YEAR)) +" trong nam.");
		
		Calendar cTemp = (Calendar) cal.clone();
		cTemp.add(Calendar.DAY_OF_WEEK, 7);
		
		System.out.println("Mot tuan sau la: " +sdf.format(cTemp.getTime()));
		
	}

}
