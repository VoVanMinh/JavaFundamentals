package bai13_VoVanMinh;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Date;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Cau2 {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner nhap = new Scanner(System.in);
		System.out.print("Nhap vao ngay thang nam theo dang dd/MM/yyyy: ");
		String str = nhap.nextLine();

		String re = "^(0[1-9]|[1-2][0-9]|3[0-1])[/](0[1-9]|1[0-2])[/](19[0-9][0-9]|[2-9][0-9][0-9][0-9])$";

		Pattern p = Pattern.compile(re);
		Matcher m = p.matcher(str);

		if (!m.matches())
			System.out.println("Date khong hop le!");
		else {
			StringTokenizer st = new StringTokenizer(str, "/");
			int ng = Integer.parseInt(st.nextToken());
			int th = Integer.parseInt(st.nextToken());
			int nam = Integer.parseInt(st.nextToken());

			if (checkDate(ng, th, nam)) {

				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

				System.out.println("Hom nay la: " + sdf.format(new Date()));
				System.out.println("Ngay thang nam sinh cua ban la: " + str);

				LocalDate today = LocalDate.now();
				LocalDate sinhNhat = LocalDate.of(today.getYear(), th, ng);

				Period pe = Period.between(today, sinhNhat);//sinhNhat - today
				if (pe.getMonths() == 0 && pe.getDays() == 0) {
					System.out.println("Chuc mung sinh nhat!");
				} else if (pe.getMonths() > 0 || (pe.getMonths() == 0 && pe.getDays() > 0)) {
					System.out.print("Sinh nhat sap den! Con ");
					System.out.println(pe.getMonths() +" thang "+ pe.getDays() +" ngay!");
				} else if (pe.getDays() < 0) {
					System.out.println("Vui long cho nam sau!");
				}

			} else
				System.out.println("Date khong hop le!");
		}
	}

	private static boolean checkDate(int ng, int th, int nam) {
		if (th == 4 || th == 6 || th == 9 || th == 11) {
			if (ng == 31)
				return false;
		}

		else if (th == 2) {
			if ((nam % 400 == 0) || (nam % 4 == 0 && nam % 100 != 0)) {
				if (ng > 29)
					return false;

			} else {
				if (ng > 28)
					return false;
			}
		}
		return true;
	}

}
