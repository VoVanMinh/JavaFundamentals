package bai1_VoVanMinh;

import java.util.Scanner;

public class Cau2 {

	public static void main(String[] args) {
		System.out.println("********************************************");
        System.out.println("\tĐăng kí thông tin học viên");
        System.out.println("********************************************");
        System.out.print("");
        Scanner in=new Scanner(System.in);
        System.out.println("Nhập thông tin: ");
        System.out.print("Họ tên: ");
        String ten=in.nextLine();
        System.out.print("Email: ");
        String email=in.nextLine();
        System.out.println("--------------------------------------------");
        System.out.println("---\tXin chào bạn "+ten+" !");
        System.out.println("---\tThông tin của bạn đã được ghi nhận");
        System.out.println("--------------------------------------------");
	}

}
