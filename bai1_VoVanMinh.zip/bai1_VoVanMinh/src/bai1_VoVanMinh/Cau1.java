package bai1_VoVanMinh;

public class Cau1 {

	public static void main(String[] args) {
		System.out.println(" **  **\t******\t**    \t**    \t **** ");
        System.out.println(" **  **\t**    \t**    \t**    \t**  **");
        System.out.println(" ******\t******\t**    \t**    \t**  **");
        System.out.println(" **  **\t**    \t**    \t**    \t**  **");
        System.out.println(" **  **\t******\t******\t******\t **** ");
	}

}
