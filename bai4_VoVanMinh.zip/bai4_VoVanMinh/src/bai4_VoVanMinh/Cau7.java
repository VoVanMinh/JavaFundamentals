package bai4_VoVanMinh;

import java.util.Scanner;

public class Cau7 {

	public static void main(String[] args) {
		
		final float B1 = (float) 0.05;
		final float B2 = (float) 0.1;
		final float B3 = (float) 0.15;
		final float B4 = (float) 0.2;
		final float B5 = (float) 0.25;
		final float B6 = (float) 0.3;
		final float B7 = (float) 0.35;
		
		final float BT1 = (float) 60;
		final float BT2 = (float) (120);
		final float BT3 = (float) (216);
		final float BT4 = (float) (384);
		final float BT5 = (float) (624);
		final float BT6 = (float) (960);
		
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Nhap vao tong thu nhap trong nam: ");
		double tongTN = sc.nextDouble();
		
		System.out.println("Nhap vao so nguoi phu thuoc: ");
		int soNguoi = sc.nextInt();
		
		double tru = 108 + soNguoi*3.6*12;
		double thue = tongTN - tru;
		System.out.println(thue);
		
		if(soNguoi <= 0 || thue <= 0)
			thue = 0;
		else if (thue > BT6)
		{
			thue = BT1*B1 + (BT2-BT1)*B2 + (BT3-BT2)*B3 + (BT4-BT3)*B4 + (BT5-BT4)*B5 + (BT6-BT5)*B6 + (thue - BT6)*B7;  
		}
		else if (thue > BT5)
		{
			thue = BT1*B1 + (BT2-BT1)*B2 + (BT3-BT2)*B3 + (BT4-BT3)*B4 + (BT5-BT4)*B5 + (thue - BT5)*B6;
		}
		else if (thue > BT4)
		{
			thue = BT1*B1 + (BT2-BT1)*B2 + (BT3-BT2)*B3 + (BT4-BT3)*B4 + (thue - BT4)*B5;
		}
		else if (thue > BT3)
		{
			thue = BT1*B1 + (BT2-BT1)*B2 + (BT3-BT2)*B3 + (thue - BT3)*B4;
		}
		else if (thue > BT2)
		{
			thue = BT1*B1 + (BT2-BT1)*B1 + (thue - BT2)*B3;
		}
		else if (thue > BT1)
		{
			thue = BT1*B1 + (BT2-BT1)*B2;
		}
		else //thue < 60
		{
			thue = thue*B1;
		}
		
		System.out.println("Tien thue phai dong la: " +thue);
		
	}

}
