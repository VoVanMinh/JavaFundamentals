package bai4_VoVanMinh;

import java.util.Scanner;

public class Cau6 {

	public static void main(String[] args) {
		
		Scanner sc =new Scanner(System.in);
		
		System.out.print("Nhap vao lua chon do C hoac do F: ");
		System.out.print("C hoac F");
		String ch = sc.nextLine();
		System.out.print("Nhap vao nhiet do!");
		float d = sc.nextFloat(); 
		
		switch (ch) {
		case "C":
			case "c":
				d = (d*9/5)+32;
				System.out.println("Nhiet do chuyen sang do F la: " +d);
			break;
		case "F":
			case "f":
				d = 5*(d-32)/9;
				System.out.println("Nhiet do chuyen sang do F la: " +d);
				break;
		default:
			System.out.print("Ban da chon sai!");
			break;
		}
	}

}
