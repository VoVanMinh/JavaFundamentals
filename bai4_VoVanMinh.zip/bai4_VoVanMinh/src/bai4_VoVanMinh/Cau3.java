package bai4_VoVanMinh;

import java.util.Scanner;

public class Cau3 {

	public static void main(String[] args) {
		 
		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap vao so kwh tieu thu: ");
		float kwh = sc.nextFloat();
		
		final float B1 = (float) 1.388;
		final float B2 = (float) 1.433;
		final float B3 = (float) 1.660;
		final float B4 = (float) 2.082;
		final float B5 = (float) 2.324;
		final float B6 = (float) 2.399;
		
		
		final float BT1 = (float) 50;
		final float BT2 = (float) (100);
		final float BT3 = (float) (200);
		final float BT4 = (float) (300);
		final float BT5 = (float) (400);		
		
		if(kwh < 0)
			kwh = 0;
		else if (kwh > BT5)
		{
			kwh = BT1*B1 + (BT2-BT1)*B2 + (BT3-BT2)*B3 + (BT4-BT3)*B4 + (BT5-BT4)*B5 + (kwh - BT5)*B6;
		}
		else if (kwh > BT4)
		{
			kwh = BT1*B1 + (BT2-BT1)*B2 + (BT3-BT2)*B3 + (BT4-BT3)*B4 + (kwh - BT4)*B5;
		}
		else if (kwh > BT3)
		{
			kwh = BT1*B1 + (BT2-BT1)*B2 + (BT3-BT2)*B3 + (kwh - BT3)*B4;
		}
		else if (kwh > BT2)
		{
			kwh = BT1*B1 + (BT2-BT1)*B1 + (kwh - BT2)*B3;
		}
		else if (kwh > BT1)
		{
			kwh = BT1*B1 + (BT2-BT1)*B2;
		}
		else //kwh < 60
		{
			kwh = kwh*B1;
		}
				
		System.out.println("Tong tien dien: "+kwh);
	}
}
