package bai4_VoVanMinh;

import java.util.Scanner;

public class Cau3 {

	public static void main(String[] args) {
		 
		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap vao so kwh tieu thu: ");
		float kwh = sc.nextFloat();
		final float B1 = (float) (50*1.388);
		final float B2 = (float) (50*1.433);
		final float B3 = (float) (100*1.660);
		final float B4 = (float) (100*2.082);
		final float B5 = (float) (100*2.324);
		final float B6 = (float) 2.399;
		
		double t = ((kwh>50)?B1:kwh*1.388) 
				+ ((kwh-50>0)?B2:0)
				+ ((kwh-100>0)?B3:0)
				+ ((kwh-200>0)?B4:0)
				+ ((kwh-300>0)?B5:0)
				+ ((kwh-400>0)?(kwh-400)*B6:0);
				
		System.out.println("Tong tien dien: "+t);
	}
}
