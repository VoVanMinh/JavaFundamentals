package bai4_VoVanMinh;

import java.util.Scanner;

public class Cau2 {

	public static void main(String[] args) {
		try
		{
			Scanner sc = new Scanner(System.in);
			
			System.out.println("Nhap loai xe (4 hoặc 7: ");
			int ip = sc.nextInt();
			
			System.out.println("Nhap so km: ");
			float km = sc.nextFloat();
			
			final float GIA = 11000f;
			
			float tt =0;
	
			if (ip == 4)
			{
				if (km < 0.8)
					tt = 11000;
				else if(km >=30)
					tt = (float) (GIA + 12400*(km-0.8));
				else
					tt = (float) (GIA + 16500*(km-0.8));
					
			}
			else if (ip == 7)
			{
				if (km < 0.8)
					tt = GIA;
				else if(km >=30)
					tt = (float) (GIA + 11440*(km-0.8));
				else
					tt = (float) (GIA + 17000*(km-0.8));
					
			}
			else
			{
				System.out.println("Ban da nhap sai!");
			}
			System.out.println("Tong tien: " +tt);
		}
		catch (Exception e)
		{
			System.out.println(e);
		}

	}

}
