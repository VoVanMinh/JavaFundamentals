package bai4_VoVanMinh;

import java.util.Scanner;

public class Cau5 {

	public static void main(String[] args) {
		try
		{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Nhap vao thang: ");
		int th = sc.nextInt();
		System.out.println("Nhap vao ngay: ");
		int ng = sc.nextInt();
		System.out.println("Nhap vao nam: ");
		int nam = sc.nextInt();
		
		if (nam < 1900 || th < 1 || th > 12 || ng <1 || ng >31 )
			System.out.println("Date ko hop le!");
		else
		{
			if (th == 1 || th == 3 || th == 5 || th == 7 || th == 8 ||th == 10)
			{
				System.out.println("Ngay hop le! Thang nay co 31 ngay");
				
				if (ng < 31)
					System.out.println("Ngay hom sau la ngay " +(ng+1) + "Thang " +th +"Nam " +nam);
				else //ng =31
					System.out.println("Ngay hom sau la ngay 1 Thang " +(th+1) +"Nam " +nam);
				
				if (ng > 1)
					System.out.println("Ngay hom truoc la ngay " +(ng-1) + "Thang " +th +"Nam " +nam);
				else //ng =1
				{	
					if (th == 3)
						System.out.println("Ngay hom truoc la ngay 28 Thang " +(th-1)+"Nam " +nam);
					else if (th == 8)
						System.out.println("Ngay hom truoc la ngay 31 Thang " +(th-1)+"Nam " +nam);
					else if (th == 1)
						System.out.println("Ngay hom truoc la ngay 31 Thang 12");
					else System.out.println("Ngay hom truoc la ngay 30 Thang " +(th-1)+"Nam " +nam);					
				}
			}
			else if (th == 4 || th == 6 || th == 9 || th == 11)
			{
				if (ng == 31)
					System.out.println("Ngay khong hop le!");
				else 
				{
					System.out.println("Ngay hop le! Thang nay co 30 ngay");
					if (ng < 30)
						System.out.println("Ngay hom sau la ngay " +(ng+1) + "Thang " +th+"Nam " +nam);
					else //ng =30
						System.out.println("Ngay hom sau la ngay 1 Thang " +(th+1)+"Nam " +nam);
					
					if (ng > 1)
						System.out.println("Ngay hom truoc la ngay " +(ng-1) + "Thang " +th+"Nam " +nam);
					else //ng =1
						System.out.println("Ngay hom truoc la ngay 31 Thang " +(th-1)+"Nam " +nam);					
					
				}
			}
			else if (th == 2)
			{
				if((nam % 400 == 0) || (nam %4==0 && nam % 100 != 0))
				{
					if (ng > 29)
						System.out.println("Ngay ko hop le!");
					else 
					{
						System.out.println("Ngay hop le! Thang nay co 29 ngay. Day la nam nhuan");
						if (ng < 29)
							System.out.println("Ngay hom sau la ngay " +(ng+1) + "Thang " +th+"Nam " +nam);
						else //ng =30
							System.out.println("Ngay hom sau la ngay 1 Thang " +(th+1)+"Nam " +nam);
						
						if (ng > 1)
							System.out.println("Ngay hom truoc la ngay " +(ng-1) + "Thang " +th+"Nam " +nam);
						else //ng =1
							System.out.println("Ngay hom truoc la ngay 31 Thang " +(th-1)+"Nam " +nam);		
				
					
					}
				}
			 else
			 {							
				if (ng > 28)
					System.out.println("Ngay khong hop le!");
				else 
				{
					System.out.println("Ngay hop le! Thang nay co 28 ngay");
					if (ng < 28)
						System.out.println("Ngay hom sau la ngay " +(ng+1) + "Thang " +th+"Nam " +nam);
					else //ng =30
						System.out.println("Ngay hom sau la ngay 1 Thang " +(th+1)+"Nam " +nam);
				
					if (ng > 1)
						System.out.println("Ngay hom truoc la ngay " +(ng-1) + "Thang " +th+"Nam " +nam);
					else //ng =1
						System.out.println("Ngay hom truoc la ngay 31 Thang " +(th-1)+"Nam " +nam);		
				}
			 }
				 
			}
			else //th =12
			{
				
					System.out.println("Ngay hop le! Thang nay co 31 ngay");
					if (ng < 31)
						System.out.println("Ngay hom sau la ngay " +(ng+1) + "Thang " +th);
					else //ng =31
						System.out.println("Chao nam moi. Ngay hom sau la ngay 1 Thang 1 nam "+(nam+1));
					
					if (ng > 1)
						System.out.println("Ngay hom truoc la ngay " +(ng-1) + "Thang " +th);
					else //ng =1
						System.out.println("Ngay hom truoc la ngay 30 Thang " +(th-1));		
			}
		}
		
		
		}catch (Exception e) {
			System.out.println(e);
		}


	}
	

}
