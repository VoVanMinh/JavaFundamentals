package bai4_VoVanMinh;

import java.util.Scanner;

public class Cau4 {

	public static void main(String[] args) {
		
		final float L1 = 1260000;
		final float L2 = 1550000;
		final float L34 = 1830000;
		final float L56 = 2120000;
		final float L7 = 2540000;
		final float L8 = 4800000;
		
		try
		{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Nhap loai phong: ");
		int loai = sc.nextInt();
		System.out.println("Nhap so dem: ");
		int sd = sc.nextInt();
		
		float tt = 0f;
		
		switch (loai) {
		case 1:
			if (sd <=1)
				tt = L1;
			else if (sd >= 4)
				tt = (float) (L1 - L1*0.25);
			else
				tt = (float) (L1 - L1*0.3);
			break;
		
		case 2:
			if (sd <=1)
				tt = L2;
			else if (sd >= 4)
				tt = (float) (L2 - L2*0.25);
			else
				tt = (float) (L2 - L2*0.3);
			break;
		
		case 3:
			case 4:
			if (sd <=1)
				tt = L34;
			else if (sd >= 4)
				tt = (float) (L34 - L34*0.25);
			else
				tt = (float) (L34 - L34*0.3);
			break;
			
		case 5:
			case 6:
			if (sd <=1)
				tt = 2120000;
			else if (sd >= 4)
				tt = (float) (L56 - L56*0.25);
			else
				tt = (float) (L56 - L56*0.3);
			break;
			
		case 7:
			if (sd <=1)
				tt = 2540000;
			else if (sd >= 4)
				tt = (float) (L7 - L7*0.25);
			else
				tt = (float) (L7 - L7*0.3);
			break;
			
		case 8:
			if (sd <=1)
				tt = L8;
			else if (sd >= 4)
				tt = (float) (L8 - L8*0.25);
			else
				tt = (float) (L8 - L8*0.3);
			break;
			
		default:
			break;
		}
		
		System.out.println("Thanh tien: " +tt);
		
		}catch (Exception e) {
			System.out.println(e);
		}

	}

}
