package bai4_VoVanMinh;

import java.util.ArrayList;
import java.util.Scanner;

public class Cau1 {

	public static void main(String[] args) {
		try
		{
			Scanner sc = new Scanner(System.in);
						
			System.out.println("Nhap a: ");
			int a = sc.nextInt();
		
			
			System.out.println("Nhap b: ");
			int b = sc.nextInt();
	
			
			System.out.println("Nhap c: ");
			int c = sc.nextInt();
			
			
			System.out.println("Nhap d: ");
			int d = sc.nextInt();
			
			
			int max, min;
			 
			min = a; max =a;
			if (min > b)
				min = b;
			if (min > c)
				min = c;
			if (min > d)
				min = d;
			
			if (max < b)
				max = b;
			if (max < c)
				max = c;
			if (max < d)
				max = d;	
			System.out.println("a=" +a+ "; b="+b+ "; c="+c+ "; d="+d);
			System.out.println("Max la: " +max + "\nMin la:" +min);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
