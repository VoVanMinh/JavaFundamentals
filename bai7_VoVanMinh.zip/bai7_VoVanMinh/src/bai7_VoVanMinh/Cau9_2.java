package bai7_VoVanMinh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Cau9_2 {
	public static void main(String[] args) throws NumberFormatException, IOException {

		int[] a = new int[5];
		nhapMang(a);
		xuatMang(a);

		csChiaHet(a);
		csGapDoi(a);
		csTongBang8(a);

	}

	private static void csChiaHet(int[] a) {

		System.out.print("\nCac cap so chia het cho nhau la: ");
		for (int i = 0; i < a.length - 1; i++) {
			for (int j = i + 1; j < a.length; j++) {
				if ((a[i] % a[j] == 0) || (a[j] % a[i] == 0)) {
					System.out.print(a[i] + " & " + a[j] + ", ");
				}
			}
		}
	}

	private static void csGapDoi(int[] a) {
		System.out.print("\nCac cap so gap doi nhau la: ");
		for (int i = 0; i < a.length - 1; i++) {
			for (int j = i + 1; j < a.length; j++) {
				if ((a[i] * 2 == a[j]) || (a[j] * 2 == a[i])) {
					System.out.print(a[i] + " & " + a[j] + ", ");
				}
			}
		}

	}

	private static void csTongBang8(int[] a) {
		System.out.print("\nCac cap so cong lai bang 8 la: ");
		for (int i = 0; i < a.length - 1; i++) {
			for (int j = i + 1; j < a.length; j++) {
				if (a[i] + a[j] == 8) {
					System.out.print(a[i] + " &" + a[j] + ", ");
				}
			}
		}

	}

	private static void nhapMang(int[] a) throws NumberFormatException, IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Nhap cac phan tu cho mang: ");
		for (int i = 0; i < a.length; i++) {
			System.out.print("Nhap phan tu thu " + (i + 1) + "= ");
			a[i] = Integer.parseInt(input.readLine());
		}
	}

	private static void xuatMang(int[] a) {
		System.out.print("Mang da nhap: ");
		for (int i = 0; i < a.length; i++) {
			System.out.print(a[i] + " ");
		}

	}
}
