package bai7_VoVanMinh;

import java.util.Scanner;

public class Cau8_4 {
	public static void main(String[] args) {

		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);

		System.out.println("Nhap vao n: ");
		int n = input.nextInt();

		System.out.println(n + "!= " + tinhGiaiThu(n));
		System.out.println(n + "!!= " + tinh2GThua(n));

	}

	private static int tinhGiaiThu(int n) {
		int n1 = 1;
		for (int i = 1; i <= n; i++) {
			n1 *= i;
		}
		return n1;
	}

	private static int tinh2GThua(int n) {
		int n2 = 1;
		int ch = n % 2;
		for (int i = 1; i <= n; i++) {
			if (ch == 0) {
				if (i % 2 == 0) {
					n2 *= i;
				}
			} else {
				if (i % 2 == 1) {
					n2 *= i;
				}
			}
		}
		return n2;
	}

}
