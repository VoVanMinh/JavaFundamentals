package bai7_VoVanMinh;

import java.util.Scanner;

public class Cau4 {

	public static void main(String[] args) {

		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
		System.out.print("Nhap vao nam sinh cua ban: ");
		int year = input.nextInt();
		if(year >= 1900)
		{	tinhChi(year);
			tinhCan(year);
		}
		else
			System.out.println("Vui long nhap nam >= 1900.");
	}

	private static void tinhChi(int year) {
		switch (year % 10) {
		case 0:
			System.out.print("Canh");
			break;

		case 1:
			System.out.print("Tân");
			break;

		case 2:
			System.out.print("Nhâm");
			break;

		case 3:
			System.out.print("Quý");
			break;

		case 4:
			System.out.print("Giáp");
			break;

		case 5:
			System.out.print("Ất");
			break;

		case 6:
			System.out.print("Bính");
			break;

		case 7:
			System.out.print("Đinh");
			break;

		case 8:
			System.out.print("Mậu");
			break;

		case 9:
			System.out.print("Kỷ");
			break;

		default:
			break;
		}

	}

	private static void tinhCan(int year) {
		switch (year % 12) {
		case 0:
			System.out.print(" Thân");
			break;

		case 1:
			System.out.print(" Dậu");
			break;

		case 2:
			System.out.print(" Tuất");
			break;

		case 3:
			System.out.print(" Hợi");
			break;

		case 4:
			System.out.print(" Tý");
			break;

		case 5:
			System.out.print(" Sửu");
			break;

		case 6:
			System.out.print(" Dần");
			break;

		case 7:
			System.out.print(" Mão");
			break;

		case 8:
			System.out.print(" Thìn");
			break;

		case 9:
			System.out.print(" Tỵ");
			break;
			
		case 10:
			System.out.print(" Ngọ");
			break;

		case 11:
			System.out.print(" Mùi");
			break;

		default:
			break;
		}


	}

}
