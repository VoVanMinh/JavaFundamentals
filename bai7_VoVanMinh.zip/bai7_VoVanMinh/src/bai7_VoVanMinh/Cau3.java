package bai7_VoVanMinh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Cau3 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Nhap vao n: ");
		int n = Integer.parseInt(input.readLine());

		int[] a = new int[n];
		System.out.println("Nhap cac phan tu cho mang: ");
		for (int i = 0; i < n; i++) {
			System.out.print("Nhap phan tu thu " + (i + 1) + "= ");
			a[i] = Integer.parseInt(input.readLine());
		}

		int len = a.length;
		System.out.print("Mang da nhap: ");
		for (int i = 0; i < len; i++) {
			System.out.print(a[i] + " ");
		}

		System.out.println("\nNhap vao x: ");
		int x = Integer.parseInt(input.readLine());

		int vt = timX(x, a);
		if (vt == -1)
			System.out.println("\n" + x + " khong xuat hien trong mang");
		else
			System.out.println("\n" + x + " xuat hien trong mang tai vi tri " + (vt+1));
	}

	private static int timX(int x, int[] a) {
		int vt = -1;
		for (int i = 0; i < a.length; i++) {
			if (a[i] == x) {
				vt = i;
				break;
			}
		}
		return vt;
	}

}
