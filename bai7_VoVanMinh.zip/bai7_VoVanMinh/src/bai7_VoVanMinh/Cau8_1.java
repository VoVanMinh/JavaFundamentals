package bai7_VoVanMinh;

import java.util.Scanner;

public class Cau8_1 {

	static boolean soNguyenTo(int x) {
		if(x < 2)
			return false;
		int c = (int) Math.sqrt(x);
		for (int i = 2; i <= c; i++) {
			if (x % i == 0) {
				return false;
			}
		}
		return true;
	}

	public static void main(String[] args) {

		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);

		System.out.println("Nhap vao n: ");
		int n = input.nextInt();
		
		System.out.println("Ket qua E = " +tinhE(n));
		
	}

	private static int tinhE(int n) {
		int E = 0;
		for (int i = 2; i <= n; i++) {
			if (soNguyenTo(i)) {
				E = E + i;
			}
		}
		return E;
	}

}
