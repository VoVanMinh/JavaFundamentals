package bai7_VoVanMinh;

import java.util.Scanner;

public class Cau5 {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);

		float canNang;
		float chieuCao;
		do {
			System.out.println("Nhap vao chieu cao: ");
			chieuCao = input.nextFloat();

			System.out.println("Nhap vao can nang: ");
			canNang = input.nextFloat();
		} while (canNang <= 0 || chieuCao <= 0);
		float BMI = tinhBMI(canNang, chieuCao);
		danhGia(BMI);

	}

	private static float tinhBMI(float canNang, float chieuCao) {
		return canNang / (chieuCao * chieuCao);
	}

	private static void danhGia(float bMI) {
		if (bMI < 18.5)
			System.out.println("Ban qua gay, an nhieu vo.");
		else if (bMI >= 25)
			System.out.println("Ban thua can, tap the duc vo");
		else
			System.out.println("Ban binh thuong. Chuc mung");
	}

}
