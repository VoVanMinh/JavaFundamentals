package bai7_VoVanMinh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

public class Cau9_3 {
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Nhap vao m (dong va cot): ");
		int m = Integer.parseInt(input.readLine());

		int[][] arr = new int[m][m];
		
		arr = mangNgauNhien(arr);
		xuatMang(arr);
		
		duongCC(arr);
		
		xuatSNTo(arr);

		
		int[][] arr2 = new int[m][m];
		nhapMang(arr2);
		xuatMang(arr2);
		
		matrandoiXung(arr2);


		int[][] arr3 = new int[m][m];
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < m; j++) {
				arr3[i][j] = arr[i][j] + arr2[i][j];
			}
		}
		xuatMang(arr3);

		System.out.println("Nhap vao cot k: ");
		int k = Integer.parseInt(input.readLine());
		kiemTraCot(arr3, k);
		
		
	}

	private static void kiemTraCot(int[][] arr3, int k) {
		int dem1 = 0;
		if (k > arr3.length)
			System.out.println(k + " qua lon!");
		else {
			for (int i = 0; i < arr3.length - 1; i++) {
				if (arr3[i + 1][k-1] < arr3[i][k-1]) {
					System.out.println("Cot " +k +" nay khong tang dan");
					dem1 = 1;
					break;
				}
			}
			if(dem1 == 0)
				System.out.println("Cot " +k +" nay tang dan");
		}
		
	}

	private static void matrandoiXung(int[][] arr2) {
		int dem = 0;
		for (int i = 0; i < arr2.length; i++) {
			if(dem == 1)
				break;
			for (int j = 0; j < arr2.length; j++) {
				if (arr2[i][j] != arr2[j][i]) {
					System.out.println("Ma tran khong doi xung.");
					dem++;
					break;
				}
			}
		}
		if (dem == 0)
			System.out.println("Ma tran nay doi xung.");
		
	}

	private static void nhapMang(int[][] arr2) throws NumberFormatException, IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Nhap vao cac phan tu trong mang: ");
		for (int i = 0; i < arr2.length; i++) {
			for (int j = 0; j < arr2[0].length; j++) {
				System.out.println("\nNhap vao phan tu dong " + (i + 1) + " cot " + (j + 1));
				arr2[i][j] = Integer.parseInt(input.readLine());
			}
		}
	}

	private static void xuatSNTo(int[][] arr) {
		System.out.println("Cac so nguyen to trong ma tran la: ");
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[0].length; j++) {
				if (soNguyenTo(arr[i][j]))
					System.out.println("\t" +arr[i][j] + " o dong " +(i+1) +" cot " +(j+1));
			}
		}
		System.out.print("\n");
		
	}

	private static void duongCC(int[][] arr) {
		int tong = 0;
		int phanTu = arr[0][0];
		for (int i = 0; i < arr.length; i++) {
			tong += arr[i][i];
			if (phanTu < arr[i][i]) {
				phanTu = arr[i][i];
			}
		}
		System.out.println("Tong gia tri tren duong cheo chinh la: " + tong);
		System.out.println("Phan tu lon nhat tren duong cheo chinh la: " + phanTu);

		phanTu = arr[0][0];
		for (int i = 0; i < arr.length; i++) {
			if (phanTu > arr[i][i]) {
				phanTu = arr[i][i];
			}
		}
		System.out.println("Phan tu nho nhat tren duong cheo chinh la: " + phanTu);
	}

	static boolean soNguyenTo(int x) {
		if(x < 2)
			return false;
		int c = (int) Math.sqrt(x);
		int i = 2;
		while (i <= c) {
			if (x % i == 0) {
				return false;
			}
			i++;
		}
		return true;
	}
	private static int[][] mangNgauNhien(int[][] a) {
		Random random = new Random();
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[0].length; j++) {
				a[i][j] = random.nextInt(20);
			}
		}
		return a;
	}

	private static void xuatMang(int[][] arr) {
		System.out.println("Ma tran da nhap la ");
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[0].length; j++) {
				System.out.print(arr[i][j] + "\t");
			}
			System.out.print("\n");
		}

	}
}
