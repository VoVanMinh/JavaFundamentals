package bai7_VoVanMinh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Cau7_3 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Nhap vao so dong: ");
		int n = Integer.parseInt(input.readLine());

		System.out.println("Nhap vao so cot: ");
		int m = Integer.parseInt(input.readLine());

		int[][] arr = new int[n][m];

		nhapMang2Chieu(arr, n, m);
		xuatMang2Chieu(arr, n, m);

		System.out.println("So phan tu chan trong mang la: " + soChan(arr, n, m));
		System.out.println("So phan tu le trong mang la: " + (n * m - soChan(arr, n, m)));

		System.out.println("Trung binh cac phan tu chan la: " + tbinhChan(arr, n, m));
		System.out.println("Trung binh cac phan tu le la: " + tbinhLe(arr, n, m));

		int gtLonNhat = giaTriLonNhat(arr, n, m);
		System.out.println("Phan tu lon nhat la : " + gtLonNhat);
		xuatViTri(arr, gtLonNhat);

		int gtNhoNhat = giaTriNhoNhat(arr, n, m);
		System.out.println("Phan tu nho nhat la : " + gtNhoNhat);
		xuatViTri(arr, gtNhoNhat);
		
		if(phanTuAm(arr))
			System.out.println("Mang co chua phan tu am.");
		else
			System.out.println("Mang khong co chua phan tu am.");
		
		int xhNhieuNhat = xhNhieuNhat(arr);
		
		phanTuXHNNhat(arr, xhNhieuNhat);
		
	}
	private static int xhNhieuNhat(int[][] arr) {
		int dem = 0;
		int[] mang = new int[arr.length * arr[0].length];

		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[0].length; j++) {
				mang[dem] = arr[i][j];
				dem++;
			}
		}
		dem = 1;
		int demLN = 1;
		for (int i = 0; i < mang.length - 1; i++) {
			dem = 1;
			for (int k = i + 1; k < mang.length; k++) {
				if (mang[k] == mang[i]) {
					dem++;
				}
			}
			if (dem > demLN) {
				demLN = dem;
			}
		}
		return demLN;
	}

	private static void phanTuXHNNhat(int[][] arr, int xhNN) {
		int dem = 0;
		int[] mang = new int[arr.length * arr[0].length];

		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[0].length; j++) {
				mang[dem] = arr[i][j];
				dem++;
			}
		}
		dem = 1;
		for (int i = 0; i < mang.length - 1; i++) {
			dem = 1;
			for (int k = i + 1; k < mang.length; k++) {
				if (mang[k] == mang[i]) {
					dem++;
				}
			}
			if (dem == xhNN) {
				System.out.println("Phan tu xuat hien nhieu nhat la: " +mang[i]);
				xuatViTri(arr, mang[i]);
			}
		}
	}

	private static boolean phanTuAm(int[][] arr) {
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[0].length; j++) {
				if (arr[i][j] < 0)
					return true;
			}
		}
		return false;
	}

	private static int giaTriLonNhat(int[][] arr, int n, int m) {
		int phanTu = arr[0][0];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (phanTu < arr[i][j]) {
					phanTu = arr[i][j];
				}
			}
		}
		return phanTu;
	}

	private static int giaTriNhoNhat(int[][] arr, int n, int m) {
		int phanTu = arr[0][0];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (phanTu > arr[i][j]) {
					phanTu = arr[i][j];
				}
			}
		}
		return phanTu;
	}

	private static void xuatViTri(int[][] arr, int gt) {
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[0].length; j++) {
				if (arr[i][j] == gt)
					System.out.println(i + ":" + j + "\t");
			}
		}
	}

	private static int soChan(int[][] arr, int n, int m) {
		int dem = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (arr[i][j] % 2 == 0)
					dem++;
			}
		}
		return dem;
	}

	private static float tbinhLe(int[][] arr, int n, int m) {
		float tongLe = 0;
		int dem = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (arr[i][j] % 2 == 1) {
					tongLe += arr[i][j];
					dem++;
				}
			}
		}
		if (dem == 0)
			return 0;
		return tongLe / dem;
	}

	private static float tbinhChan(int[][] arr, int n, int m) {
		float tongChan = 0;
		int dem = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (arr[i][j] % 2 == 0) {
					tongChan += arr[i][j];
					dem++;
				}
			}
		}
		if (dem == 0)
			return 0;
		return tongChan / dem;
	}

	private static void xuatMang2Chieu(int[][] arr, int n, int m) {
		System.out.println("Mang hai chieu da nhap la ");
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				System.out.print(arr[i][j] + "\t");
			}
			System.out.print("\n");
		}

	}

	private static void nhapMang2Chieu(int[][] arr, int n, int m) throws NumberFormatException, IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Nhap vao cac phan tu trong mang: ");
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				System.out.println("\nNhap vao phan tu dong " + (i + 1) + " cot " + (j + 1));
				arr[i][j] = Integer.parseInt(input.readLine());
			}
		}

	}

}
