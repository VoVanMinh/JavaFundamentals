package bai7_VoVanMinh;

import java.util.Scanner;

public class Cau8_2 {

	public static void main(String[] args) {

		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);

		System.out.println("Nhap vao so nhi phan n: ");
		int n = input.nextInt();
		
		System.out.println("So thap phan la: " +doi2den10(n));

	}

	private static int doi2den10(int n) {
		int M = 0;
		int i = 0;
		while (n != 0) {
			M += (n % 10) * Math.pow(2, i);
			n = n / 10;
			i++;
		}

		return M;
	}
}
